# NeuralEDGE & Zoo Media — Complete Knowledge Export

**Owner:** ML (Yatharth Garg), Founder & CEO, NeuralEDGE
**Generated:** April 19, 2026
**Source:** Consolidated from all past Claude conversations + memory

---

## What's Inside

This zip contains everything I have about NeuralEDGE, NEOS, Zoo Media, and every project/person/system around it — extracted from our past chats and organized into a structured archive.

```
neuraledge_export/
├── README.md                          ← You are here
│
├── 01_company/
│   ├── 01_overview.md                 ← NeuralEDGE company overview, founding, mission
│   ├── 02_team.md                     ← Core team bios and roles
│   └── 03_business_model.md           ← Service tiers, pricing, ICP
│
├── 02_neos_platform/
│   ├── 01_neos_architecture.md        ← NEOS 3-layer architecture (NEC, NEOS, NEOPS)
│   ├── 02_neops_catalog.md            ← All named NEops (Aria, Recon, Forge, etc.)
│   ├── 03_neps_marketplace.md         ← NePs and NEOP Marketplace economics
│   └── 04_openclaw_runtime.md         ← OpenClaw deployment details
│
├── 03_clients/
│   ├── 01_clients_roster.md           ← All clients and prospects
│   ├── 02_zoo_media_full.md           ← Complete Zoo Media engagement dossier
│   ├── 03_zoo_media_decks.md          ← Zoo Media pitch deck details
│   └── 04_zoo_icd_neop.md             ← ICD NEop build for Zoo Media
│
├── 04_tech_and_memory/
│   ├── 01_tech_stack.md               ← Full tech stack
│   ├── 02_context_vault.md            ← Context Vault architecture
│   ├── 03_cortex_palace_v3.md         ← CORTEX-PALACE memory system (v3 final)
│   └── 04_infrastructure.md           ← AWS, Matrix, Convex setup
│
├── 05_gtm/
│   ├── 01_gtm_engine.md               ← GTM strategy and targets
│   ├── 02_icp_library.md              ← 35-doc ICP library summary
│   └── 03_outreach_playbook.md        ← Outreach approach
│
├── 06_projects/
│   ├── 01_named_builds.md             ← All projects (Neural, TeamPulse, PULSE, etc.)
│   ├── 02_nexus_alte.md               ← NEXUS and ALTE B2B intelligence
│   ├── 03_customer_connect_emma.md    ← Emma WhatsApp shopping agent
│   └── 04_axe_content_engine.md       ← Axe self-improving content engine
│
├── 07_legal_and_fundraising/
│   ├── 01_legal_templates.md          ← NDA, MSA, SOW, etc.
│   ├── 02_pitch_decks.md              ← Deck suite and design system
│   └── 03_build3_bar_raiser.md        ← build3 6-pager details
│
└── 08_chat_index/
    └── conversation_index.md          ← Index of every chat with URL + topic
```

---

## How to Use This

- **Read the README** (this file) for orientation
- **Start at `01_company/01_overview.md`** for top-down understanding
- **Jump to `03_clients/02_zoo_media_full.md`** for Zoo Media deep-dive
- **Use `08_chat_index/conversation_index.md`** to find the original chat for anything

## Important Notes

1. **This is a derived archive** — content is synthesized from my memory and past-chat search results. It is NOT the raw export from Settings → Privacy → Export Data.
2. For the **raw conversation JSON**, use Settings → Privacy → Export Data (email link will arrive).
3. Links in `conversation_index.md` are in the format `https://claude.ai/chat/{uri}` — you must be logged in.
4. Dates/facts as of my last interaction with you. Cross-check anything mission-critical.

---

*Compiled by Claude on April 19, 2026*
