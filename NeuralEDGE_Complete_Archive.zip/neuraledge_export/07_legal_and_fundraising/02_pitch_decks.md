# Pitch Decks & Design System

## Complete Deck Suite

Built in **PptxGenJS** + HTML (scroll-snap format):

1. **Investor Pitch Deck** — for fundraising (build3, future rounds)
2. **Zoo Media Client Deck (v2 recut)** — 105 slides — client pitch
3. **Tech Partners Deck** — for tech partnership conversations
4. **Consulting Firms Deck** — for peer consulting firms (coopetition)
5. **Clients Deck** — generic client pitch (modular template)
6. **NEOS 6-Pager** — build3 Bar Raiser document
7. **Marketplace Monetization (4-pager)** — Zoo Media follow-up

## Design System

### Brand Colors (Canonical)
- **Navy:** `#132F48`
- **Teal:** `#13C5B3`
- **Ice:** `#EFF4F9`

### Alternative Palette (used in some decks)
- `--teal: #00C9A7`
- `--dark: dark navy`
- `--light: off-white`
- `--gray: body gray`

### Typography
- **Space Grotesk** — Display / headlines
- **DM Sans** — Body text
- **JetBrains Mono** — Monospace accents

### Aesthetic Directives
- Dark navy + teal
- Scroll-snap slides (for HTML decks)
- Floating orbs (teal + navy, low opacity)
- Glassmorphic cards
- Fade-up animations on scroll
- Grid pattern overlays
- Cinematic feel

### Layout Components
- Section number (`01`, `02`, `03`) in mono font
- Section label (small caps)
- Large section title with colored accent word
- Body paragraphs in `--light` color
- Card grids (3–4 cards per row)
- Callout boxes with left teal border
- Two-column splits
- Stat row (4 big stats in row)
- Team cards (name, role, bio)
- FAQ accordion
- Fund table with teal-highlighted totals

## Key Deck Frameworks

### Worldbuilding Writer Framework
Applied across decks. Principles:
- **Cognitive hospitality** — make reader feel smart
- **Atomic units** — smallest possible message per slide
- **Frame shift** — collapse old mental model, introduce new one
- **Reach from ground truth** — start where reader lives, pull them somewhere new

### Zoo Media Deck Frameworks
- **Identity lock** (opening) — "You are the 600-animal zoo"
- **Industry mirror** — "Here's what the industry is becoming"
- **Frame shift** — "AI = tools" → "AI = employees that use tools for you"
- **Dune micro-detail** — CTO-grade technical depth where it matters
- **Himish pattern** — Named protagonist story (Priya at FoxyMoron)
- **Trust architecture** — milestone-by-milestone transparency
- **Zerodha principle** — salary comparison, not abstract ROI %
- **Tribal signaling** — "we build together"

## HTML Deck Technical Stack

- Pure HTML + CSS + minimal JS
- No framework dependency (standalone file)
- Scroll-snap for slide-like experience
- Grid + flex for layouts
- CSS variables for theming
- Fade-up animations with IntersectionObserver

## Sample Slide Structure (HTML)

```html
<section id="solution">
  <div class="section-num">01</div>
  <div class="section-label fade-up">The Solution</div>
  <h2 class="section-title fade-up">
    NEOS is the <span>execution layer</span> for the AI-native enterprise.
  </h2>
  <p class="body-text fade-up">It gives any founder a complete AI workforce...</p>
  <div class="card-grid fade-up">
    <div class="card">
      <div class="card-icon">⚡</div>
      <h3>QuickBuildAI</h3>
      <p>Tell NEOS what your business does...</p>
    </div>
    <!-- more cards -->
  </div>
  <div class="callout fade-up">
    <p><strong>The Critical Insight:</strong> ...</p>
  </div>
</section>
```

## Navigation Pattern

- Sticky top nav with section anchors
- Confidential badge (top right)
- Active state highlights current section
- Smooth scroll on click

## Footer (standard)

```
[Brand: NEOS]
NeuralEDGE | Synlex Technologies PVT. LTD. — An Intelligence Ventures Portfolio Company
March 2026 | Confidential | Prepared for [audience]
```

## Deck Production Workflow

1. **Write content first** (outline all slides)
2. **Run through Worldbuilding framework** (cognitive hospitality pass)
3. **Build HTML skeleton** (sections, placeholders)
4. **Apply design system** (colors, typography, animations)
5. **Fill content** (section-by-section)
6. **Review and tighten** (cut any slide that doesn't earn its place)
7. **Test scroll behavior** across screen sizes
8. **Screenshot each section** for static distribution (Playwright automated)
9. **Deliver as HTML file + screenshots + (optional) PDF export**

## Recurring Team Slide Content

**4 Team Cards (standard):**

1. **Yatharth Garg (YG) — Founder & CEO**
   ASU dropout. Business strategy, product vision, investor relations. Building toward the single-person billion-dollar company vision.

2. **Dr. Rahul Kashyap — Co-Founder & CTO**
   PhD in AI/ML. All technology and technical strategy for NEOS. Deep research expertise in multi-agent systems and enterprise AI architecture.

3. **Mansi Gambhir — Tech Lead, India**
   Ex-DRDO, Ex-Samsung AI. Leads engineering team. Drives NEop runtime development, agent orchestration, and platform infrastructure.

4. **+3 NEOS Consultants — Forward Deployed**
   Specialists who deploy, customize, and optimize NEops directly inside client organizations.

## Recurring Stat Row (Proof Points)

```
50–100x    |    7%         |    30 min    |    Day 1
FASTER     |    PRODUCTIVITY|    NEW LEAD  |    NEOS SELF-
LEAD       |    BOOST       |    TAT       |    DEPLOYMENT
RESPONSE   |    (MONTH 1)   |              |
```

All from Shinon Global engagement.

## Recurring Case Study Blocks

### Shinon Global
"Lead Response TAT reduced from 24–48 hours to 30 minutes (50–100x improvement). Chief of Staff NEop drove 7% individual productivity boost in Month 1."

### Zoo Media
"India's largest independent agency network. 8 agencies. 600 people. 2,500+ brands. ICD NEop deployed across the network."

### Von Albert
"Berlin luxury real estate. AI-native transformation across sales and operations."

### Additional clients (compact one-liners when needed)
- Breakfree — ongoing engagement
- Yoga Studio Chain — Recon SDR (US/GB)

## Sharing / Distribution

- HTML file (primary format)
- PDF export (for email attachment)
- Section screenshots at 1440×900 (for text-based messaging — LinkedIn DMs, WhatsApp)
- Playwright automation used to generate screenshots
