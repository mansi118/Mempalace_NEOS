# build3 Bar Raiser — Fundraising Documentation

## What build3 Is

- **build3** = Varun Chawla's Startup Studio
- NeuralEDGE pitched to build3 as a portfolio company candidate
- Fundraising round: **₹25 Lakhs**

## The NEOS 6-Pager (Bar Raiser Document)

### Document Format
- Amazon-style 6-pager narrative document
- Written and iterated multiple rounds
- Renders as HTML with NeuralEDGE design system

### Document Title
> **NEOS — The Operating System for the AI-Native Enterprise**
> A complete AI workforce that handles execution across every business function from Day 1.

### Confidentiality
- Badge: CONFIDENTIAL
- Date: March 2026
- Prepared for build3 Bar Raiser Review

## 6-Pager Section Structure

### 01 — Problem Statement
**Headline:** Starting a business has never been easier to imagine — and never been harder to execute.

**3 Compounding Blockers:**

1. **Cost of hiring a team to execute**
   - Sales, marketing, ops, finance, research — ₹30–50L/year before ₹1 in revenue
2. **Complexity of running operations**
   - 70%+ of founder time lost to operational overhead
3. **Time from idea to running business**
   - 6–12 months to get to a functioning business; burns runway before PMF

**Result:** Millions of startups never launch. The ones that do are structurally disadvantaged.

### 02 — The Solution
**Headline:** NEOS is the **execution layer** for the AI-native enterprise.

**4 Platform Pillars:**

| Pillar | Description |
|--------|-------------|
| ⚡ **QuickBuildAI** | Tell NEOS what your business does. Deploys full AI digital employee team in minutes. |
| 🔲 **AgentSpace** | Notion-like docs + Slack-like messaging workspace where you coexist with AI team. |
| 📊 **NEE (NeuralEDGE Evals)** | Your AI team gets better every day. Continuous evaluation, self-improvement. |
| 🔒 **Context Vault** | Company + Private context — nothing is ever lost. Every interaction deepens org intelligence. |

**Critical Insight:**
> "The single-person billion-dollar company is no longer a thought experiment — it's an architectural inevitability."

### 03 — Goals
Year 1 targets:
- 25–50 customers
- $1M+ ARR
- 100+ NEOps deployed
- >90% customer retention
- 50+ marketplace listings
- >60 NPS
- 10+ domain SLMs

### 04 — Values
Core thesis and company values (abundance through AI, etc.)

### 05 — Business Model
Three-phase evolution:
- Phase 1 (Now): Consulting
- Phase 2 (Nov 2026): SaaS
- Phase 3 (2027+): Marketplace

### 06 — Strategic Priorities & Use of Funds

**Total Raise: ₹25,00,000 from build3**

**GTM — 80% / ₹20,00,000:**
- **Paid Ads (₹8L):** Targeted LinkedIn and Google campaigns aimed at SMB founders, agency owners, mid-market decision-makers
- **Content & Brand (₹6L):** Axe content engine fuel — LinkedIn thought leadership, blog series, case studies, video content
- **Outreach & Sales (₹6L):** Recon SDR pipeline — Apollo/Proxycurl credits, email infrastructure, NEOS Consultant deployment for free POC delivery

**Infrastructure — 20% / ₹5,00,000:**
- **AWS Compute & Storage (₹3L):** EC2 scaling, Context Vault (Convex), model inference as client base grows
- **Security & Tooling (₹2L):** API costs (OpenAI, Anthropic, Proxycurl), monitoring, compliance tooling

**Previous funding structure (removed):**
- Old 4-category split (Engineering 40%, GTM 25%, Infrastructure 20%, Marketplace 15%) — replaced
- "Friends & Family Round" — removed
- References to additional angel investors — removed

### 07 — Lessons
Key learnings from previous work and pivot

### 08 — FAQ
Anticipated investor questions with pre-written answers covering:
- Competitive landscape ("No one else has built the full stack. NEOS is the only solution combining agent deployment, workspace, persistent memory, self-improving skills, integrated evals, multi-agent orchestration in one SMB-ready platform.")
- Why no competitor at ₹20–25L ACV for SMBs
- Moat: Context Vault + NEOP Marketplace + self-improving NePs

## Traction Proof Points (in Bar Raiser)

### Case Study 1: NeuralEDGE Internal (Dogfooding)
"Our sales pipeline, prospect research, email sequences, and internal ops are powered by NEops deployed inside AgentSpace. If it doesn't work for us, we don't ship it to clients. This is the strongest proof point we have: NEOS isn't a demo — it's how we operate every day."

### Case Study 2: Shinon Global (Flagship)
- Lead Response TAT: 24–48 hours → 30 minutes (50–100x improvement)
- Chief of Staff NEop: 7% individual productivity boost in Month 1
- Self-improving NeP loop means number compounds monthly

### Stat Bar (replaces previous 4-stat bar)
| 50–100x | 7% | 30 min | Day 1 |
|---------|-----|--------|-------|
| FASTER LEAD RESPONSE | PRODUCTIVITY BOOST (MONTH 1) | NEW LEAD TAT | NEOS SELF-DEPLOYMENT |

### Additional Clients (compact one-liners)
- Zoo Media — India's largest independent agency network, ICD NEop delivered
- Von Albert — Berlin luxury real estate transformation
- Unboorred Club — archived engagement

**Removed from older versions:**
- Original Zoo Media / Von Albert / Unboorred Club case studies with old metrics (30–70% time savings, 2–3x efficiency) — replaced by Shinon as primary

## Companion Outreach to Varun Chawla

Used in outreach email:

> "We'll help Build3 productise its service offerings so they can scale beyond what your team can do manually. You'll see tangible value within the first week of our engagement.
>
> To make this completely risk-free: full money-back guarantee for the entire first month. If at any point you don't see the value, ask for your money back — no questions. We continue only if it makes sense to you.
>
> Honestly, this is also the best way for you to experience the power of what we've built firsthand — before you ever consider investing anything into us. Use it, see the impact on Build3's own operations, and then decide.
>
> Also, would love your feedback on the NEOS Bar Raiser I sent over — especially how it maps to your investment thesis.
>
> Happy to jump on a quick call whenever works for you."

**Why this works:**
- Tangled: NeuralEDGE as service vendor to Build3 + NeuralEDGE as investment candidate
- Money-back guarantee removes risk
- Feedback request tied to "your investment thesis" → specific, not generic
- "Quick call" CTA is low-commitment

## Current Status

- Bar Raiser document written and iterated through multiple edit rounds
- 4 major edits completed:
  - **Edit #1:** [unspecified]
  - **Edit #2:** [unspecified]
  - **Edit #3:** Traction section rewrite — Shinon as primary, Zoo/Von Albert/Unboorred as compact one-liners
  - **Edit #4:** Use of Funds scoped to ₹25L with detailed breakdown table
- PR write-up also updated to reference Shinon Global
- Edit tracker marked complete

## Long-term Fundraising Path

After ₹25L from build3:
- PMF estimate: ₹25L sufficient for 4–6 months runway to PMF
- Next round: to scale GTM once 30–50 clients proven
- Path to SaaS transition (Phase 2) requires platform product investment
