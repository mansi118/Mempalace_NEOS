# Legal Document Template System

## Scope

**200+ templates** across all document types needed for:
- Indian B2B AI consulting engagements
- Client onboarding (NDA → Discovery → SOW → MSA → Invoice)
- Ongoing operations (change requests, DPAs, addendums)
- Marketplace operations

## Core Document Suite

### 1. NDA (Non-Disclosure Agreement)
- **Template File:** `NE-NDA-Template.docx`
- **Mutual structure** (both parties protect each other's info)
- **Key clauses:**
  - AI-specific confidentiality (protects NEOS/NeP IP)
  - Data handling obligations
  - 2-year survival clause
  - Injunctive relief available without proving damages
  - Governing law: India
  - Jurisdiction: per engagement config

### 2. MSA (Master Services Agreement)
- **Template File:** `NE-MSA-Template.docx`
- **Umbrella contract** that governs all individual SOWs
- **Deal Info Table fields:**
  - Agreement Date → `engagement.effective_date`
  - Client Legal Name → `client.legal_name`
  - Client Brand Name → `client.brand_name`
  - Engagement Type → `engagement.type`
  - Engagement Tier → `engagement.tier`
  - Term (Months) → `engagement.term_months`
  - Monthly Retainer (INR) → `engagement.retainer_monthly_inr`
  - Dispute Resolution → `engagement.dispute_resolution`
  - Deal ID → `deal_id`

**MSA Sections:**
1. Deal Info Table (auto-populated)
2. Recitals — who NeuralEDGE is, who client is
3. Definitions — NEOS, NEop, NeP, NEC, NEOP Marketplace, AI Digital Employee, Consultant, Business Executive, Deliverables, Retainer, SOW
4. Scope of Services — three-service model (Audit, Implementation, Training)
5. Retainer & Payment Terms
6. Retainer Reassessment (every 3 months / quarterly)
7. Intellectual Property
8. Remedies
9. Governing Law
10. Signature Block (NeuralEDGE: Yatharth Garg, Founder & CEO / Client: authorized signatory)

### 3. SOW (Statement of Work)
- **Template File:** `NE-SOW-Template.docx`
- **Deliverable-focused** operational contract
- **Sections:**
  1. Deal Info Table
  2. Reference to governing MSA
  3. Scope of Work (narrative)
  4. **Deliverable Matrix** — table: ID | Deliverable | Description | Deadline | Acceptance Criteria | Assigned Resource | Status
  5. Resource Allocation (NEops, Consultants, Business Executives)
  6. NEOS Value Schedule (what client gets at retainer level + quarterly reassessment note)
  7. NEC Access (NEop slots, NeP access, marketplace listing rights)
  8. NEOP Marketplace (60/40 profit split if client lists custom NEop)
  9. Timeline & Milestones
  10. Acceptance Process (5 biz days review, written feedback, deemed-accepted if no response)
  11. Change Request Process (reference MSA)
  12. Assumptions & Dependencies
  13. Signature Block

### 4. DPA (Data Processing Agreement)
- Standard for clients needing GDPR/data compliance
- Required for international clients (Von Albert Germany)

### 5. Proposal
- Pre-contract persuasive document on NeuralEDGE letterhead
- **Sections:**
  1. Deal Info Table
  2. Executive Summary (2–3 paragraphs — why client needs AI transformation)
  3. Understanding Your Challenges (industry pain points, 50%+ knowledge worker ICP frame)
  4. Our Approach (three-phase model)
  5. What You Get (resources table at proposed retainer level)
  6. Investment (retainer, GST, payment terms, quarterly reassessment)
  7. NEOP Marketplace Opportunity (40% profit share)
  8. Why NeuralEDGE (differentiators)
  9. Next Steps (NDA → SOW → MSA → Kick-off)
  10. Validity (30 days)
  11. Signature Block (NeuralEDGE only — it's a proposal, not a contract)

### 6. Invoice
- GST-compliant format
- TDS auto-calculated (Section per commercial config)
- Payment terms visible

### 7. Engagement Agenda (Discovery Call)
- Used during AI Audit discovery phase

## Supporting Templates

- Change Request (CR)
- Addendum
- Payment Reminder
- Engagement Kick-off Checklist
- Acceptance Form
- Milestone Sign-off
- Final Delivery Memo
- Engagement Close-out Report

## Automation Plan

Designed for future automation via **NE-GTM NEop** (Go-to-Market automation).

**Target flow:**
```
Deal closed in CRM (Convex)
  ↓
NE-GTM triggers document generation
  ↓
Pulls from Deal Schema (engagement, client, commercial, deliverables, resources_allocated)
  ↓
Populates templates with `{{placeholders}}`
  ↓
Outputs NDA → Proposal → MSA → SOW as .docx
  ↓
Sends to client for e-signature (future: DocuSign integration)
```

## Deal Schema (JSON structure)

```
{
  "deal_id": "NE-2026-XXX",
  "client": {
    "legal_name": "...",
    "brand_name": "...",
    "industry": "...",
    "authorized_signatory": { ... },
    "knowledge_worker_percentage": ...
  },
  "engagement": {
    "type": "audit | implementation | training | full",
    "tier": "1 | 2",
    "effective_date": "...",
    "term_months": ...,
    "retainer_monthly_inr": ...,
    "retainer_reassessment_cycle_months": 3,
    "jurisdiction": "...",
    "dispute_resolution": "..."
  },
  "commercial": {
    "payment_due_days": ...,
    "gst_rate": 18,
    "tds_rate": 10,
    "tds_section": "194J",
    "payment_mode": "..."
  },
  "deliverables": [ ... ],
  "resources_allocated": {
    "neops": [ ... ],
    "consultants": [ ... ],
    "business_executives": [ ... ]
  },
  "nec_access": {
    "neop_slots": ...,
    "nep_access_enabled": true,
    "marketplace_listing_enabled": false
  }
}
```

## Letterhead & Branding

All documents use NeuralEDGE letterhead:
- Navy (#132F48) + Teal (#13C5B3) color scheme
- Space Grotesk / DM Sans / JetBrains Mono typography
- Professional B2B tone throughout

## Document Generation Skill

- **Skill:** `neuraledge-doc`
- **Location:** `/mnt/skills/user/neuraledge-doc/SKILL.md`
- **Function:** Generate personalized NeuralEDGE client documentation from 200+ templates
- **Triggers:** Requests to create NDA, SOW, MSA, invoice, discovery agenda, proposal, case study, audit report, project charter, or any client-facing documentation
