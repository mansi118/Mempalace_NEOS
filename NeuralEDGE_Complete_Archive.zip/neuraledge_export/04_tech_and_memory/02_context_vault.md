# Context Vault — The Unified Memory Layer

## What Context Vault Is

Context Vault is the **central knowledge layer** for all NEops — the shared brain of a NeuralEDGE deployment.

**Dual-scope architecture:**
- **Company Scope** — Organization-wide shared context (accessible to all NEops in that tenant)
- **Private Scope** — Per-NEop private context (isolated)

## The Problem It Solves

Three failure modes that kill multi-agent systems:

1. **Context Fragmentation** — Aria knows about a client conversation. Recon doesn't. Forge builds something that contradicts what Scout discovered. Every agent operates in its own isolated reality.

2. **Knowledge Decay** — Decisions, strategies, and learnings evaporate between sessions. The organization can't compound intelligence — it resets to zero every conversation.

3. **No Coherence Protocol** — No access rules, no consistency model, no conflict resolution. When two agents write contradicting facts, who wins? Currently nobody knows.

## Reference Proof Point: Legion Health

Legion Health (YC S21) built a unified data layer across records, prescriptions, scheduling, messaging, and follow-up — then connected specialized AI agents to that single source of truth. Result: tripled patient count with one added ops hire.

**Architecture maps 1:1 to NEOS:**

| Legion Health | NEOS / Context Vault |
|---------------|---------------------|
| Agent drift — isolated agents diverge | NEops need shared organizational context |
| Unified data layer all agents read & write to | Context Vault (Company + Private) on Convex |
| Specialized role-based agents | NEops (Aria, Recon, Forge, Scout, Axe, Emma) |
| Patient records, prescriptions, scheduling, billing | Company knowledge, private context, operational data |
| Full-stack ownership enables full personalization | Context Vault gives every NEop full org awareness |
| AI handles default, clinicians handle exceptions | NEops handle default, humans handle exceptions via TeamComs |

## Context Vault Implementation (v1 → v2)

### v1: CORTEX (initial design)
- 5 custom agents
- OpenAI embeddings
- In-memory prototype
- NEop-centric
- Conversation memory focus

### v2: Context Vault (evolved)
- 3 custom agents + AgentCore managed
- Titan Embed v2 (512 dims) — native AWS, 90% cheaper
- Graphiti + Convex + AgentCore — production day 1
- Source-centric ingestion (data enters from Telegram, Fireflies, Drive, GitHub)

### v3: CORTEX-PALACE (final)
See `03_cortex_palace_v3.md` for full architecture.

## Three-Layer Architecture (v2)

```
LAYER 1: INGESTION
  Agents that watch data sources and feed the graph
  ├─ Comms Ingester     → Telegram, WhatsApp, Email
  ├─ Meeting Ingester   → Fireflies (MCP)
  ├─ Document Ingester  → Google Drive (MCP)
  └─ Project Tracker    → GitHub, Convex, TeamPulse
  
  graphiti.add_episode()
       ↓
LAYER 2: THE GRAPH
  Graphiti temporal KG — single source of truth
  
  Entities: Person, Client, Project, Document, Issue, 
            Invoice, Meeting, NEop, Decision
  
  Every edge has: valid_from, valid_until, source, confidence
  
  Storage: FalkorDB (dev) → Neptune Analytics (prod)
  Embeddings: Titan Embed v2 (512 dims) → S3 Vectors
  
  Plus: Convex for core memory blocks + raw message log
       ↓
LAYER 3: RETRIEVAL
  Per-NEop views with ACL enforcement
```

## 5 Custom Agents (v1 design)

| Agent | LLM | Purpose | Latency |
|-------|-----|---------|---------|
| **Extractor** | gpt-4.1-mini | Pulls facts from user+assistant messages | 500ms async |
| **Consolidator** | gpt-4.1-mini | Resolves conflicts with existing facts | 500ms async |
| **Reflector** | gpt-4.1-mini | Turns situation/action/outcome into lessons | 1s async |
| **Curator** | gpt-4.1-mini | Promotes recurring patterns to core memory | 2s periodic |
| **Assembler** | gpt-4.1-mini | Decides what memories matter for this query | 800ms blocking |

**Total overhead:** ~800ms blocking + ~1s async per turn

## Why Context Vault is Novel

### vs Mem0
Mem0 does vector + graph + KV but with procedural logic. No agent makes judgment calls. Mem0 is a storage layer; Context Vault is a thinking layer.

### vs Letta
Letta requires the NEop itself to manage memory via tool calls (`core_memory_append`, `archival_memory_insert`). The NEop has to decide what to remember while doing its actual job. Context Vault separates concerns — the NEop thinks, the agents remember.

### vs AgentCore Memory
AgentCore provides managed storage + extraction. But extraction is one-size-fits-all. No domain-specific judgment. No cross-agent consolidation. Context Vault uses AgentCore as a storage backend but adds the judgment layer.

### vs Graphiti
Graphiti is the best temporal KG engine. But it doesn't decide what goes into the KG. It doesn't decide what's relevant at query time. Context Vault uses Graphiti as the temporal backbone and adds agentic curation on top.

**Context Vault = Letta's memory model + Graphiti's temporal engine + Memoria's session intelligence + AgentCore's episodic learning + 5 autonomous agents that make it all work together.**

## NEop-Specific Memory Use

| NEop | Primary Memory Use | Special Requirements |
|------|-------------------|---------------------|
| **ICD** | Client brand preferences, past creative decisions, feedback patterns | High persona fidelity, visual preference tracking |
| **Recon** | Lead qualification data, outreach history, response patterns | Cross-session lead state, objection tracking |
| **Axe Cortex** | Content performance data, tone preferences, topic history | Self-improving NeP feeds back content metrics |
| **NEXUS** | Company graphs, stakeholder maps, deal history | Heavy KG usage, Neo4j graph traversal |
| **ALTE** | Person-level behavioral patterns, communication preferences | Privacy-sensitive, strict isolation |
| **COS** | Meeting history, action items, decision logs | Cross-NEop memory aggregation |
| **NE-GTM** | Campaign performance, market signals, competitive intel | Orchestrates memory from sub-agents |

## Hooks Into OpenClaw

1. **Heartbeat Hook** — Every heartbeat, Context Vault checks if new messages need logging
2. **Session Save Hook** — Every 10 messages: log messages, update summary, extract KG triplets, recalc weights
3. **Pre-Compact Hook** — Before context window compression: emergency save, summarize, extract
4. **Session Close Hook** — Final summary, persona update, token aggregation

## Self-Improving Context Vault NeP

Track:
- Retrieval accuracy (was assembled context actually useful?)
- Token efficiency (context size vs. task completion)

Self-tune:
- Weight parameters (α, β, γ)
- Summary frequency
- Token budget

## Memory Operations

### Writing (Ingestion)
```
Input Event → Classify → Categorize → Route → Extract → Store → Link
```

### Reading (Retrieval)
```
Query → Parse (Wing/Hall/Room) → Retrieve → Augment → Rank → Return
```

### Lifecycle
```
ACTIVE → SUMMARY → ARCHIVE → DECAY
         (raw)     (condensed) (indexed) (pruned if stale)
```
