# NeuralEDGE — Complete Tech Stack

## Production Stack

| Layer | Technology | Notes |
|-------|-----------|-------|
| **Frontend** | TanStack Start | React framework |
| **Backend** | Convex | Reactive DB, replacing FastAPI in some contexts |
| **Agent Orchestration** | FastAPI | For integration endpoints |
| **NEop Runtime** | OpenClaw (unforked) | v2026.3.3 |
| **Primary LLM** | Claude API | Anthropic, via Claude Sonnet |
| **Secondary LLM** | Z.AI / GLM-5 | For OpenClaw production runtime |
| **Memory/Knowledge** | Context Vault | Dual-scope: Company + Private |
| **Embeddings (Dev)** | Gemini embedding-001 | Via Google API |
| **Embeddings (Prod)** | Qwen3-Embedding-8B (self-hosted) | For PrivatNEOS deployments |
| **Graph DB** | FalkorDB + Graphiti | Temporal knowledge graph |
| **Infrastructure** | AWS EC2 | Ubuntu 24.04, ap-south-1 |
| **Deployment** | systemd service | Matrix channel integration |
| **Team Comms** | Self-hosted Matrix | matrix.neuraledge.in |

## Complete Dependency Map

### Frontend
- **TanStack Start** — Router and SSR
- **React** — Component library
- **Tailwind CSS** — Styling
- **shadcn/ui** — Component library for artifacts

### Backend / Data
- **Convex** — Source of truth, reactive DB, real-time subscriptions
- **FalkorDB** — Graph database (Redis-based, Cypher queries)
- **Graphiti** — Temporal knowledge graph on top of FalkorDB
- **Neo4j** — Alternative graph option evaluated for NEXUS

### Agent Infrastructure
- **OpenClaw** — Agent runtime (unforked)
- **AWS Strands SDK** — For Axe Content Engine and Emma
- **MCP (Model Context Protocol)** — Tool connection layer
- **A2A / ACP** — Agent-to-agent communication (planned integration)

### LLMs
- **Claude (Anthropic)** — Primary reasoning model
- **Claude Sonnet 4.6** — For semantic extraction in CORTEX
- **Z.AI GLM-5** — Production OpenClaw agents
- **Gemini** — Embeddings and some specialized tasks

### Data Sources / APIs (evaluated/used)
- **Apify** — Web scraping (Recon yoga studio agent)
- **Firecrawl** — Web content extraction
- **Fireflies** — Meeting intelligence
- **Vexa** — Meeting intelligence (alt option)
- **Proxycurl** — LinkedIn data (paid, for ALTE)
- **Apollo** — Sales intelligence (paid, for ALTE)
- **People Data Labs (PDL)** — Person data (paid)
- **Hunter** — Email finding (paid)
- **OpenAI API** — Embeddings (initial Context Vault version)
- **AWS Personalize** — Recommendations (Emma)

### Storage
- **Supabase** — Some Emma components
- **MongoDB** — Some Emma components
- **Redis** — Caching (Emma cart state)
- **Razorpay** — Payments (Emma)

### Infrastructure
- **AWS EC2** — Compute (t3.medium, ap-south-1)
- **Ubuntu 24.04 LTS** — OS
- **Docker** — Containerization
- **systemd** — Service management
- **nginx** — Reverse proxy (when needed)
- **Tailscale** — Mesh VPN for private access
- **Let's Encrypt / certbot** — SSL certs

### DevOps / Security
- **UFW** — Firewall
- **fail2ban** — Intrusion prevention
- **SSH** — Admin access only (port 22, IP-locked)

### Communication Channels
- **Matrix** — @openclaw/matrix v2026.3.12 (primary)
- **Element** — Matrix client (element.neuraledge.in)
- **Telegram** — Bot integration (TeamPulse)
- **WhatsApp** — QR pairing (Emma)
- **Slack** — Integration target

## MAGMA Memory Architecture (Next-Gen)

Planned upgrade over flat vector search for Context Vault:

- **Multi-graph substrate:** semantic + temporal + causal + entity
- Prototype-first approach before porting to production
- Paper being evaluated for integration

## Rejected / Evaluated Alternatives

| Evaluated | Verdict | Why |
|-----------|---------|-----|
| **ChromaDB** | Discarded | Convex replaces it |
| **SQLite KG** | Discarded | FalkorDB + Graphiti gives real Cypher |
| **LangGraph** | Rejected | OpenClaw chosen instead |
| **CrewAI** | Rejected | OpenClaw chosen instead |
| **Mem0** | Rejected | Procedural logic, no agent judgment |
| **A-MEM** | Rejected | From CORTEX research |
| **LangMem** | Rejected | From CORTEX research |
| **Cognee** | Rejected | From CORTEX research |
| **Memoria** | Evaluated | Worth inspiration, not full implementation |
| **Letta / MemGPT** | Evaluated | Core memory model inspired Letta-style blocks |
| **Graphiti / Zep** | Evaluated & adopted | Temporal KG backbone |
| **AgentCore** | Evaluated | Episodic memory strategy inspiration |
| **Titan Embed v2** | Evaluated | Native AWS, 90% cheaper than OpenAI |
| **S3 Vectors** | Evaluated | Vector storage for prod |
| **ElastiCache Valkey** | Evaluated | Hot-path cache |

## Model Cost / Performance Notes

- Total memory agent overhead: ~800ms blocking + ~1s async
- Cost per turn: ~5 mini calls × $0.0004 = ~$0.002/turn
- At 1000 turns/day = $2/day for memory agents

## Self-Knowledge & Personal Tools

- **Claude Code** — ML is a daily user
- **SuperClaude Framework** — Explored
- **Pi Agents** — Reference SDK architecture studied
- **gstack** (Garry Tan) — Deep-dived; wrapped in NE-GSTACK

## GCP / Gemini Issues (Top of Mind)

- Billing cap issue causing 429 errors on image generation workloads
- Options: force Tier 2 upgrade via tax info + manual payment OR route image generation to alternative provider
