# CORTEX-PALACE v3 — Final Memory Architecture

## What This Is

CORTEX-PALACE is the unified memory layer for NEOS. Every NEop — across every client deployment — reads and writes through it.

**Design principles:**
- **Multi-tenant from day 1** — client isolation is architectural, not policy
- **Cloud-native on Convex** — real-time subscriptions, reactive to writes
- **Real graph intelligence** — FalkorDB + Graphiti for multi-hop corridor queries
- **Stores verbatim, compresses at read time** — no information loss on ingestion
- **Extracts with Claude, not regex** — semantic classification, not pattern matching
- **Maps cleanly to NEOS 3-tier memory model** — Memory → Cortex → Context Vault

The palace metaphor is the UX and routing logic. Convex + FalkorDB + Gemini embeddings is the actual infrastructure.

## What We Took from MemPalace

| MemPalace Concept | Verdict | NEOS Implementation |
|---|---|---|
| Palace metaphor (Wings/Halls/Rooms) | ✓ Steal | Convex tables with hierarchical IDs + Graphiti community nodes |
| Hall-type classification | ✓ Steal | Memory/Cortex/Context Vault tier mapping |
| 170-token L0/L1 wake-up | ✓ Steal | Convex query returning index, not content |
| PALACE_PROTOCOL prompt injection | ✓ Steal | Injected in MCP status response |
| Verbatim storage (closets) | ✓ Steal | Raw text always preserved in Convex documents |
| AAAK compression | ✓ Adapted | Applied at read time (retrieval), not write time |
| ChromaDB | ✗ Discard | Convex replaces it |
| SQLite KG | ✗ Discard | FalkorDB + Graphiti for real Cypher |
| Rule-based regex extraction | ✗ Discard | Claude Sonnet 4.6 for extraction + classification |
| Local-only architecture | ✗ Discard | Cloud-native, multi-tenant from day 1 |
| 384-dim default embeddings | ✗ Discard | Gemini Embedding (768 dims) |
| Single-user filesystem | ✗ Discard | Convex multi-tenant with per-tenant ACL |

## Palace Hierarchy

```
Tenant (Client or NeuralEDGE Internal)
  └── Palace (1 per tenant)
        └── Wing (Department/Function)
              └── Hall (Memory Type)
                    └── Room (Entity/Context)
                          └── Item (Memory Record)
```

**Every address is fully qualified:**
`tenant/palace/wing/hall/room/item_id`

Example: `zoo_media/hq/synlex/decisions/icd_engagement/decision_014`

## The NeuralEDGE HQ Palace (Template for All Tenants)

```
Palace: NeuralEDGE HQ
│
├── 🏗️ Wing: NEOS Platform & NEops
├── 🤝 Wing: Clients
├── 👥 Wing: Team
├── 🚀 Wing: GTM & Sales
├── ⚖️ Wing: Legal & Finance
├── 🔬 Wing: R&D & Context Vault
├── 🏪 Wing: NeP Marketplace & Ecosystem
└── 🔧 Wing: Infrastructure & Ops
```

## Wing Breakdown (Summary)

### 🏗️ NEOS Platform & NEops
- **Decisions Hall:** Stack Choices, Architecture, Pricing, NEop Design
- **Facts Hall:** Tech Stack Registry, NEop Catalog, API Contracts, Feature Registry, Retired Components
- **Tasks Hall:** Sprint Backlog, Blocked Items, Roadmap Milestones
- **Procedures Hall:** NEop Deployment Playbook, Context Vault Operations, NEOS Onboarding
- **Lessons Hall:** Architecture Lessons, NEop Performance

### 🤝 Clients (one sub-wing per client)
Each client sub-wing has: Decisions, Facts, Conversations, Tasks, Lessons halls.
- Active sub-wings: Zoo Media, Breakfree, Von Albert, Shinon Global, Yoga Studio
- Archived: Unborred Club

**Shared Rooms (cross-client):**
- Client Health Dashboard
- Cross-Client Patterns
- Testimonials & Case Studies
- NEOp Deployment Map

### 👥 Team
- **Preferences Hall (Context Vault):** Per-person blocks for Yatharth, Rahul, Mansi, Shivam, Naveen, Ankit
- **Lessons Hall:** What Worked, What Failed
- **Tasks Hall:** Individual Assignments

### 🚀 GTM & Sales
- **Decisions:** Positioning, Channel Strategy, Content Strategy, Outreach Strategy
- **Facts:** ICP Library (35 industries), Pipeline, Competitive Intel, Content Library, Sub-Agent Registry
- **Tasks:** Outreach Queue, Content Pipeline, Campaign Operations, HITL Review Queue
- **Conversations:** Prospect Conversations, Internal GTM Syncs
- **Lessons:** Outreach Lessons, Content Lessons, Conversion Lessons

### ⚖️ Legal & Finance
- **Facts:** Entity Structure (Synlex Technologies PVT. LTD., Intelligence Ventures), Compliance Registry, Financial Snapshot, Business Model, Market Sizing
- **Tasks:** Filings & Renewals, Pending Invoices, Contract Renewals
- **Decisions:** IP Strategy, Pricing Decisions, Investment Strategy
- **Procedures (NePs):** Client Engagement Legal Flow NeP, Financial Operations NeP

### 🔬 R&D & Context Vault
- **Facts:** Research Library (Memoria, MAGMA, Graphiti, Letta, etc.), Context Vault Architecture, Experiment Registry
- **Decisions:** Memory Architecture, Agent Framework, Self-Improvement Loop
- **Lessons:** Memory System Lessons, Agent Architecture Lessons
- **Tasks:** Active Research, Tech Debt

### 🏪 NeP Marketplace & Ecosystem
- **Facts:** NeP Registry, Marketplace Economics, Ecosystem Partners, NEop Catalog (Deployable)
- **Decisions:** Marketplace Strategy, NeP Design Standards, Partnerships
- **Lessons:** NeP Performance Data, Marketplace Learnings
- **Signals:** Usage Analytics, Quality Alerts
- **Procedures:** NeP Publishing Workflow, NeP Self-Improvement Protocol

### 🔧 Infrastructure & Ops
- **Facts:** Server Registry (AWS EC2 ap-south-1, Matrix homeserver), Service Map, Credentials Vault (pointers only)
- **Tasks:** Incident Queue, Maintenance Schedule
- **Signals:** Health Metrics, Cost Alerts
- **Procedures (NePs):** Deployment NeP, Incident Response NeP, Linux Admin Runbook
- **Lessons:** Outage Post-Mortems

## Storage Layer Mapping

| Palace Component | Storage Layer |
|-----------------|---------------|
| Facts Hall (Context Vault tier) | Letta-style Core Memory (Convex documents, always in context) |
| Decisions Hall (Cortex tier) | Graphiti Temporal KG (nodes: decisions, edges: reasons, temporal validity) |
| Conversations Hall (Memory → Cortex) | Memoria Progressive Summarization (raw → summary → archive) |
| Lessons Hall (Cortex tier) | Graphiti Temporal KG (pattern nodes, causal edges) |
| Tasks Hall (Memory tier, active) | Convex Reactive DB (real-time subscriptions) |
| Preferences Hall (Context Vault) | Letta-style Core Memory (per-entity blocks) |
| Procedures Hall (Cortex-fed) | NePs (Skill.md-like + metrics + feedback loop) |
| Signals Hall (Memory tier) | Convex Reactive DB + Event Stream (TTL-based) |
| Wing/Room Metadata | Convex Document + Graphiti Community Detection |

## Cross-Wing Connections (Corridors)

Memory doesn't live in silos. Corridors are cross-references between rooms in different wings:

| Corridor | Connects | Example |
|----------|----------|---------|
| Client ↔ Platform | Client needs → NEop features | Zoo Media ICD → ICD NEop architecture |
| Client ↔ Team | Client assignments → team workload | Zoo Media tasks → Shivam's backlog |
| GTM ↔ Client | Pipeline → active engagement | Lead qualified → Client sub-wing created |
| GTM ↔ Lessons | Outreach results → pitch improvements | Lost deal → deck update |
| R&D ↔ Platform | Research findings → architecture changes | Graphiti eval → Context Vault update |
| Legal ↔ Client | Contract terms → engagement scope | MSA signed → deliverables room populated |
| Signals ↔ Tasks | Alert triggered → task created | Downtime alert → incident task |
| Team ↔ Procedures | Skill gaps → training procedures | Naveen needs Linux → Linux runbook |

**Implementation:** Graphiti edges between nodes in different wings, typed by corridor name.

## Auto-Population Rules

| Source | Auto-Routes To | Trigger |
|--------|---------------|---------|
| Fireflies meeting transcript | Conversations Hall → appropriate Wing | Meeting ends |
| Matrix/Slack message | Conversations Hall (if substantive) | Message tagged or keyword match |
| Git commit | Platform → Tasks Hall (completed) | PR merged |
| TeamPulse check-in | Team → Tasks + Signals | Pulse response received |
| Invoice sent | Legal → Tasks Hall (Pending Invoices) | Invoice generated |
| NEop execution log | Platform → Signals Hall | Execution completes |
| NeP performance metric | Marketplace → Signals Hall | Metric threshold crossed |
| AWS CloudWatch alert | Infra → Signals Hall | Alert fires |
| Email from client | Clients → Conversations Hall | Email classified as client-related |
| Decision made in chat | Decisions Hall → appropriate Wing | CORTEX detects decision pattern |

## New Client Palace Initialization

When a new client engagement starts, the palace auto-scaffolds:

```
1. GTM Pipeline → Deal Closed
2. CORTEX creates Sub-Wing under Clients:
   └── Sub-Wing: [Client Name]
       ├── Decisions Hall → Room: Engagement Scope (from SOW)
       ├── Facts Hall
       │   ├── Room: Contract & Budget (from signed MSA/SOW)
       │   ├── Room: Contacts (from CRM/discovery)
       │   └── Room: Client Environment (from audit report)
       ├── Conversations Hall → Room: Discovery Notes
       ├── Tasks Hall → Room: Active Deliverables (from SOW)
       └── Lessons Hall (empty, populates over engagement)
3. Corridors:
   └── Client ↔ Team (assignments)
   └── Client ↔ Platform (NEop deployments)
   └── Client ↔ Legal (contract reference)
```

## Key V3 Decisions

1. **Convex as source of truth** — Everything writes here first
2. **FalkorDB + Graphiti NOT deferred** — Must be Phase 1 (for cross-wing corridor queries)
3. **Claude Sonnet for semantic extraction** — Not regex, not rules
4. **Two-phase embedding strategy:**
   - Phase 1: Gemini embedding-001 (via API, development)
   - Phase 2: Qwen3-Embedding-8B (self-hosted, PrivatNEOS)
5. **Verbatim storage** — Never compress at write; compress at read
6. **AAAK at retrieval** — Answers/Assumes/Avoids/Knowledge compression
