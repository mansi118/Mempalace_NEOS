# Infrastructure — AWS, Matrix, Convex Setup

## AWS EC2 Production

- **Account:** NeuralEDGE / Synlex Technologies
- **Region:** ap-south-1 (Mumbai)
- **Public IP:** 13.233.60.59
- **OS:** Ubuntu 24.04 LTS
- **Instance Type:** t3.medium (2 vCPU, 4GB RAM)
- **Storage:** 30–40GB SSD

### What Runs on this EC2
- OpenClaw v2026.3.3 (agent runtime)
- Multiple NEops as systemd services
- Matrix bridge plugin (@openclaw/matrix v2026.3.12)
- TeamPulse Telegram bot
- Ancillary monitoring/healthcheck scripts

### Security Configuration
- **SSH (port 22):** Locked to specific IP `122.162.150.22/32`
- **Gateway (port 18789):** Loopback only, not exposed externally
- **UFW:** Enabled
- **fail2ban:** Active
- **Access pattern:** SSH tunnel or Tailscale only
- **Container hardening:** no-new-privileges, read-only, cap_drop ALL

## Matrix Self-Hosted

- **Homeserver:** matrix.neuraledge.in
- **Element Web Client:** element.neuraledge.in
- **Purpose:** Team communications for NeuralEDGE
- **Also bridged to:** matrix-client.matrix.org for OpenClaw bot interactions

### Bot Account
- **Bot User:** @naveensynlex:matrix.org
- **DM Policy:** `pairing` (user must explicitly pair with bot)
- **E2EE:** Disabled (not required)

## Convex (Reactive Database)

### Role
- **Source of truth** for all CORTEX-PALACE memory
- Powers reactive subscriptions for real-time updates
- Stores core memory blocks, raw message logs, session summaries

### What's in Convex
- Letta-style core memory blocks (always-in-context)
- Raw message log (append-only)
- Session summaries (key-value by session_id)
- Agent audit log (debugging, see why memory was extracted/skipped)
- Hierarchical palace IDs (tenant/palace/wing/hall/room/item)
- Per-tenant ACLs

### Why Convex (vs alternatives)
- Real-time sync out of the box
- TypeScript-first
- No separate caching layer needed for hot-path
- Replaces FastAPI in many contexts

## FalkorDB + Graphiti

### FalkorDB
- Graph database based on Redis
- Full Cypher query support
- Used for: multi-hop corridor queries across wings

### Graphiti
- Temporal KG library on top of FalkorDB
- Tracks entity resolution, temporal validity (valid_from, valid_until)
- Community detection for auto-clustering

### Entities Tracked
- Person, Client, Project, Document, Issue, Invoice, Meeting, NEop, Decision

### Every Edge Has
- valid_from (when relationship started)
- valid_until (when it ended or null if current)
- source (which data source this came from)
- confidence (0.0 – 1.0)

## Google Workspace

- **Gmail MCP** — Integrated for Gmail automation
- **Google Drive MCP** — For document ingestion
- **Google Calendar MCP** — For scheduling NEops
- Gemini embeddings API used for CORTEX phase 1

## Fireflies

- **Integration:** MCP server
- **Purpose:** Meeting transcription and summary
- **Feeds:** Conversations Hall in CORTEX-PALACE
- **Auto-routes:** Meeting transcripts → appropriate Wing based on participants/topic

## TeamPulse System

- **Platform:** Telegram bot
- **Frequency:** 30-minute pulse cycles
- **Deployment:** AWS EC2
- **Purpose:** Team status updates, standup replacement
- **Output:** Feeds Team wing → Tasks Hall + Signals Hall

## Network Access Patterns

### For ML (Admin)
```bash
# SSH tunnel
ssh -i key.pem -N -L 18789:127.0.0.1:18789 openclaw@13.233.60.59

# Then access dashboard at http://127.0.0.1:18789
```

### Via Tailscale (always-on)
```bash
sudo tailscale serve https / http://127.0.0.1:18789
# Access via https://hostname.tailnet.ts.net
```

## Ongoing Ops

### Auto-Updates
- Systemd timer with update.sh script
- Docker: pull + up -d + image prune -f

### Log Rotation
- Weekly: prune session transcripts >30 days
- Daily: docker log cleanup (168h retention)

### Health Checks
- Custom healthcheck.sh
- Monitors OpenClaw gateway availability
- Alerts on uptime/latency/error anomalies

### Backups
- Convex has built-in snapshots
- EC2: manual AMI snapshots
- Matrix: regular data exports

## Known Issues / Top of Mind

### GCP / Gemini API
- Billing cap issue causing 429 errors on image generation workloads
- Options being evaluated:
  - Force Tier 2 upgrade via tax info + manual payment
  - Route image generation to alternative provider
