# NeuralEDGE — Core Team

## Leadership

### Yatharth Garg (ML)
- **Role:** Founder & CEO
- **Age:** 21
- **Background:** ASU dropout (dropped out to build NeuralEDGE)
- **Focus:** Business strategy, product vision, investor relations
- **Operating Style:** Direct, concise, no filler, bias to action
- **Languages:** English, Hindi, Hinglish
- **Location:** Delhi, India

### Dr. Rahul Kashyap
- **Role:** Co-Founder & CTO
- **Background:** PhD in AI/ML (ASU, referenced in early decks as PhD candidate)
- **Focus:** All technology and technical strategy for NEOS
- **Specialty:** Multi-agent systems, enterprise AI architecture

### Mansi Gambhir
- **Role:** VP of AI Research / Tech Lead, India
- **Background:** Ex-DRDO, Ex-Samsung AI
- **Focus:** Engineering team leadership, NEop runtime development, agent orchestration, platform infrastructure

## NEOS Consultants (Forward-Deployed)

These consultants deploy, customize, and optimize NEops directly inside client organizations.

| Name | Role |
|------|------|
| **Shivam Singh** | NEOS Consultant |
| **Naveen Bisht** | NEOS Consultant |
| **Ankit** | NEOS Consultant |

## Team Capacity

- Current team can service **up to 100 clients** without hiring
- Target: 30 clients in the next 3 months (as of early 2026)
- Each engagement staffed with 1 NEOS Consultant + 1 Account Executive

## Team Communications

- **Matrix homeserver:** matrix.neuraledge.in (self-hosted on AWS)
- **Element:** element.neuraledge.in
- All team comms run on self-hosted Matrix infrastructure
