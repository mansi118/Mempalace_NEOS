# NeuralEDGE — Company Overview

## Identity

- **Legal Entity:** Synlex Technologies PVT. LTD. (trading as NeuralEDGE)
- **Holding Structure:** Intelligence Ventures (portfolio company)
- **Founded:** August 2024
- **Tagline:** "Your AI Partners"
- **Headline:** "AI does the robot work. Your team does the real work."
- **HQ:** Delhi, India
- **Website:** neuraledge.in
- **Contact:** info@neuraledge.in | yatharth@neuraledge.in | +91 9958282084

## Founders

- **Yatharth Garg (ML)** — Founder & CEO
  - 21 years old, based in Delhi
  - Dropped out of Arizona State University to build NeuralEDGE
  - Goes by "ML" day-to-day
  - Communicates in English, Hindi, and Hinglish
- **Dr. Rahul Kashyap** — Co-Founder & CTO
  - PhD in AI/ML

## Origin Story

NeuralEDGE originated as **Synlex Intelligence** (legal AI, 3B-parameter Indian legal drafting model) in August 2024. After finding no PMF in legal AI, the company pivoted to AI digital employees — becoming NeuralEDGE.

## Core Thesis

> AI creates abundance. Small teams can now achieve output that previously required hundreds of people. We help businesses get there by designing, building, deploying, and managing AI-powered digital employees — AI agents that handle real knowledge work, 24/7, within a company's specific workflows and protocols.

## Business Model Evolution

| Phase | Status | Model |
|-------|--------|-------|
| **Phase 1 (Now)** | Active | AI Consulting — Audit, Build, Train |
| **Phase 2 (Nov 2026)** | Planned | SaaS — NEOS self-deployment |
| **Phase 3 (2027+)** | Planned | NEOP Marketplace — rent AI agents as digital workforce |

## North Star

> "The single-person billion-dollar company is no longer a thought experiment — it's an architectural inevitability."

One person + a NEOS workforce of NEOps = the operating capacity of a 50-person team.

## Year 1 Targets

- 25–50 customers
- $1M+ ARR
- 100+ NEOps deployed
- >90% customer retention
- 50+ marketplace listings
- >60 NPS
- 10+ domain SLMs (small language models)

## Market Sizing

- **TAM:** $150B+ (2028)
- **SAM:** $15–20B
- **SOM:** $5–15M (18-month horizon)
- **Target Gross Margin:** 70%+

## Roadmap

- **Software Intelligence (Now):** NEOS platform, NEops, NeP marketplace
- **Physical Intelligence (Robotics/Embodied AI):**
  - Beta: November 2026
  - GA: January 1, 2027
  - (Note: Later revised to Beta Nov 2028 / GA Jan 1, 2029 in one conversation — verify current)
