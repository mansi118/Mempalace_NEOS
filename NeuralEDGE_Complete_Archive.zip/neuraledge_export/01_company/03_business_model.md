# NeuralEDGE — Service Model, Pricing & ICP

## Three Core Services

### 1. AI Audit
- Deep-dive into client's workflows, teams, and operational bottlenecks
- Maps tasks currently handled by knowledge workers that can be augmented or automated by AI
- Prioritized opportunity map ranked by impact, feasibility, ROI
- Clear roadmap with recommendations on which digital employees to build first
- **Who buys:** Companies that know AI matters but don't know where to start
- **Sales angle:** Low commitment, high insight — smart first step

### 2. AI Digital Employee Implementation (Build & Deploy)

**Two-Tier Engagement Model:**

**Tier 1 — Prove Value (Month 1)**
- Build 1–2 NEop digital employees for the client within the first month
- Fully functional AI agents deployed into actual workflows (not demos or POCs — real production agents)
- Goal: show measurable value fast
- Low-friction, low-risk entry point

**Tier 2 — Full NEOS Deployment**
- After Tier 1 proves ROI, upsell to full NEOS platform deployment
- Bigger retainers = more Consultants & Business Executives
- Reduces NEC costs over the long term

### 3. AI Training
- Upskill client teams on AI adoption
- Workshop curricula for the AI age

## Pricing (as of 2026)

- **Model:** Monthly retainer
- **Target deal size for 2026:** ₹3–6L/month retainer
- **Minimum engagement length:** None
- **Retainer reassessment:** Every 3 months (quarterly) for evolving scope
- **Payment terms:**
  - GST applicable
  - TDS under relevant section
  - Payment via bank transfer typically
- **NEOP Marketplace profit split:** 60% NeuralEDGE / 40% Client (when client's custom NEop is rented out)

## Zoo Media Pricing Options (3 entry points)

1. **Free trial** — Single AI employee free for 2 weeks
2. **AI Audit** — Starts at ₹1.5 lakhs
3. **Full engagement** — Starts at ₹25 lakhs (one-time investment size, not per month) for private AI models

## ICP (Ideal Customer Profile)

**Master Filter:** Industries where 50%+ of the workforce are knowledge workers.

### Tier 1 (Primary Focus — India Service-Based)
- Marketing / Creative / Media Agencies
- Professional Services (Legal, CA, Consulting)
- Real Estate / Wellness / Hospitality

### Tier 2 (Secondary Focus)
- EdTech
- Staffing
- Architecture

### Other Validated Sectors
- Accounting Firms
- Legal / Law

### Company Size Sweet Spot
- 50–200 employees (mid-market — easiest to close and get meetings)

### Geography
- India-first (primary)
- International: Berlin (Von Albert), US/GB (yoga studio chain) already served

## Deal Structure Components

Each engagement includes:
- **NEop slots** on NeuralEDGE Cloud (NEC)
- **NeP access** (NeuralEDGE Protocols)
- **Allocated Consultants** and Business Executives
- **Optional:** NEOP Marketplace listing rights
