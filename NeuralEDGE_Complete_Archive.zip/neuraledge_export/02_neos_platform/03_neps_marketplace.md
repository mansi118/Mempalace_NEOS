# NePs & NEOP Marketplace

## NePs — NeuralEDGE Protocols

**Definition:** Self-improving Skill.md-like files that use metrics, measurements, and every relevant performance signal to continuously optimize themselves.

### Key Properties
- Skill.md-like markdown files with structured protocols
- Embedded metrics and measurements
- Continuous self-optimization loop
- Purchasable from the NEOP Marketplace
- Each NEop gets protocols from NePs installed in its workspace (`PROTOCOLS.md`)

### Self-Improvement Loop
```
Execute → Evaluate (NE-Eval) → Learn (Cortex) → Rewrite Protocol → Improve
```

### NeP Types (examples)
- Client Engagement Legal Flow NeP — NDA → Discovery → SOW → MSA → Invoice lifecycle
- Financial Operations NeP
- Deployment NeP
- Incident Response NeP
- Linux Admin Runbook NeP (Ubuntu 24.04)
- Outreach Playbook NeP
- Discovery Call Script NeP
- Proposal Generation NeP
- Demo Playbook NeP
- CRM NeP (partially built — retired)
- NeP Publishing Workflow
- NeP Self-Improvement Protocol

## NEOP Marketplace

**The ecosystem for any business adopting NEOS as their Digital AI OS.**

### What the Marketplace Offers
- **NePs** — Purchasable self-improving protocols
- **NEops** — Rent AI agents as digital workforce

### Economics
- **Client Custom NEop Revenue Share:** 60% NeuralEDGE / 40% Client
- Example: If Zoo Media's ICD NEop is rented by another agency, Zoo earns 40%

### Marketplace Pitch (to Zoo Media)
> "The ICD system we're building together isn't just for Zoo Media. It's a product. And when other agencies rent it, you get paid."

The pitch reframes from "we hired NeuralEDGE to automate our content" to "we're building an asset that earns royalties forever."

### Marketplace Strategy Questions (open)
- Open vs curated listings
- Quality gates
- Listing criteria
- Pricing tiers (rental vs purchase)

## NeP + Marketplace = The Ecosystem

**NeP + NEOP Marketplace** = the ecosystem for any business adopting NEOS as their Digital AI OS.

## Measurement Standards

What makes a good NeP:
- Measurable outputs
- Self-improvement requirements
- Standard measurement protocol
- Feedback loop from usage metrics

## Marketplace Operations

### NeP Performance Data Tracked
- Which NePs improve fastest
- Which plateau
- Optimization patterns that work

### Signal Monitoring
- Usage analytics (trending, declining)
- Quality alerts (degrading NePs, user complaints, performance regressions)
