# NEOPS Catalog — All Named Digital Employees

## What is a NEop?

A NEop is a configured OpenClaw agent instance combining six primitives:

| Primitive | What It Provides | Source of Truth |
|-----------|-----------------|-----------------|
| **Identity** | Name, role, personality, ethical rules, operating boundaries | `SOUL.md`, `AGENTS.md` |
| **Memory** | Working context, episodic logs, curated semantic knowledge | `MEMORY.md`, `memory/*.md`, `sessions/*.jsonl` |
| **Capabilities** | Installed business workflows and domain-specific procedures | `PROTOCOLS.md` (from NePs) |
| **Tools** | Executable actions — browser, shell, APIs, NeP custom tools | `TOOLS.md`, `openclaw.json` |
| **Channels** | Communication interfaces — WhatsApp, Slack, email, web, API | Channel adapter bindings |
| **Execution** | OpenClaw Gateway process — the agentic loop engine | `openclaw.json` runtime config |

## Complete NEops Roster

| NEop | Function | Status |
|------|----------|--------|
| **Aria** | SDR (Sales Development Rep) / HR | Active |
| **Recon** | Lead Generation | Active (yoga studio chain) |
| **Forge** | Engineering | Active |
| **Scout** | Research (floater, triggered by any agent) | Active |
| **Axe (Axe Cortex)** | Content Engine | Active (Strands SDK + Convex) |
| **Emma** | Customer Connect / WhatsApp Commerce | Active |
| **COS** | Chief of Staff | Active (Tier 0 executive orchestrator) |
| **ICD** | Image Content Director | Delivered (Zoo Media) |
| **NE-HERMES** | Self-improving skill loop agent | Retired (replaced by NePs) |
| **NE-GSTACK** | Wraps gstack (Garry Tan's slash-command AI factory) | v0.1.0 |
| **NE-GTM** | Go-to-market automation (future: legal doc automation) | Planned |
| **NEXUS** | Company-level B2B intelligence | In development |
| **ALTE** | Person-level B2B intelligence | In development |
| **NeuralChat** | Interface NEop | Active |
| **Neural** | ML's personal AI executive assistant | Active |

## Hierarchy (CoS as Meta-Orchestrator)

```
         ┌─────────┐
         │   ML    │  Principal — final authority
         └────┬────┘
              │
         ┌────┴────┐
         │   CoS   │  Tier 0 — executive orchestrator
         └────┬────┘
              │
    ┌─────────┼─────────┬──────────┬──────────┐
    │         │         │          │          │
┌───┴──┐ ┌───┴──┐ ┌────┴───┐ ┌───┴──┐ ┌────┴───┐
│ Aria │ │Recon │ │ Forge  │ │  Axe │ │ Emma   │
│ (HR) │ │(SDR) │ │(Engg)  │ │(Cont)│ │(CustCx)│
└──────┘ └──────┘ └────────┘ └──────┘ └────────┘
  Scout ─── Research (floater, triggered by any agent)
```

## NEop Profiles

### Aria (SDR / HR)
- Senior SDR for NeuralEDGE
- First point of contact for sales activity
- Researches leads, crafts outreach, manages pipeline, triggers proposal workflows
- **Lead Scoring Model:** ICP Fit (35%) + Engagement (25%) + Intent (25%) + Timing (15%)
  - HOT (≥80): Immediate outreach, trigger proposal pipeline
  - WARM (60-79): Nurture sequence, weekly touchpoints
  - COOL (40-59): Monitor, send educational content
  - COLD (20-39): Low priority, quarterly check
  - Disqualify (<35): Remove from active pipeline

### Recon (Lead Generation)
- Built on OpenClaw for yoga studio leads (US/GB markets)
- Tech stack: Apify + Firecrawl + Convex
- Deep web research capability

### Axe / Axe Cortex (Content Engine)
- Self-improving marketing content agent modeled on Chroma's Context-1
- NeP-based self-optimization
- Stack: AWS Strands SDK + Convex backend
- Tracks which content performs, feeds back into future generation

### Emma (Customer Connect / WhatsApp Shopping)
- WhatsApp-based e-commerce agent
- Stack: Strands framework, Redis, MongoDB, Supabase, Razorpay, AWS Personalize, virtual try-on
- Features:
  - Product discovery, search, recommendations
  - Shopping cart management
  - Virtual try-on (upload photo → see how clothes look)
  - Order placement with COD, UPI, cards
  - 7-day conversation memory
  - 24/7 availability

### COS (Chief of Staff)
- Tier 0 executive orchestrator
- Meta-orchestrator sitting above all other NEops
- Delegates to Aria, Recon, Forge, Axe, Emma
- Scout used as floater for research
- Built with full system design, Pi agent backend, and deployment package

### ICD (Image Content Director)
- First NEop delivered to Zoo Media
- Role: Client-facing content creation across 2,500+ brand accounts
- Capabilities:
  1. Brief Interpretation — reads client briefs, extracts requirements
  2. Visual Direction — generates image concepts, mood boards
  3. Content QA — reviews against brand guidelines
  4. Multi-format Adaptation — one concept → Instagram, LinkedIn, Twitter, Stories, Reels
  5. Performance Learning — tracks which content performs best
  6. Client Reporting — auto-generates per-brand performance reports

### NEXUS (Company-level B2B Intelligence)
- Neo4j graph database of companies
- Two-phase: Discovery → Deep Research
- Sources: LinkedIn, Substack, blogs, news, press, websites, job postings
- Job postings are signal gold (5 "Sales Ops" roles = broken CRM)
- Sprint 1 = Neo4j schema + Discovery Agent

### ALTE (Person-level B2B Intelligence)
- Person-level dossier builder
- 6 pipeline stages, 8 data blocks
- 6 context modes: sales, investor, meeting prep, etc.
- 3-tier monitoring with delta profiling
- Integration point: NEXUS `(:Person)` nodes are stubs that ALTE fills in

### Neural (ML's Personal AI Executive Assistant)
- Deployed on OpenClaw
- Files: SOUL.md, MEMORY.md, HEARTBEAT.md, 12 skill files
- Team-wide expansion plan (NEURAL-TEAM-DEPLOYMENT-PLAN.md) for Rahul, Mansi, Shivam, Naveen, Ankit

### NE-HERMES (Retired)
- Built from scratch using self-improving skill loop patterns from Nous Research's Hermes Agent
- Retired — replaced by NePs

### NE-GSTACK
- Wraps gstack as-is for v0.1.0 before customizing
- Deep-dives completed on gstack philosophy: "Boil the Lake," "Search Before Building," sprint process, 28+ skills

### NE-GTM
- Go-to-market automation NEop
- Future: legal doc automation
- Sub-agents: Recon SDR, Axe Cortex, NetworkIQ, StrategyIQ

## NEop Access Patterns

Each NEop gets a **view** of the palace — not full access:

| NEop | Wings Accessible | Primary Halls |
|------|-----------------|---------------|
| Aria (EA) | All wings | Facts, Tasks, Signals (read), Conversations |
| Recon (SDR) | GTM, Clients | Facts, Tasks, Procedures |
| ICD | Clients (own), Platform | Facts, Decisions, Procedures |
| Axe Cortex | GTM, R&D | Facts, Lessons, Procedures (NePs) |
| COS | All wings | All halls (read), Tasks (write) |
| NEXUS | GTM, Clients | Facts, Signals |
| ALTE | Clients, GTM | Facts, Conversations |
| Forge | Platform, R&D, Infra | All halls |
| Scout | R&D, GTM | Facts, Lessons |
| Emma | Team, Infra, Legal | Tasks, Procedures, Signals |
| NeuralChat | All wings | Facts (read), Conversations |
