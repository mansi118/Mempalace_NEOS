# OpenClaw — The NEop Runtime

## What OpenClaw Is

OpenClaw is the **unforked** agent runtime that NeuralEDGE uses as the foundation for NEops. It's the "execution engine" that makes NEops actually run.

## Why Unforked
NeuralEDGE intentionally does NOT fork OpenClaw — it uses it as-is with extensions via plugins and workspace configs. This keeps upgrades clean.

## Production Deployment

| Component | Detail |
|-----------|--------|
| **OS** | Ubuntu 24.04 LTS on AWS EC2 |
| **Region** | ap-south-1 (Mumbai) |
| **IP** | 13.233.60.59 |
| **Instance Type** | t3.medium (2 vCPU, 4GB RAM) |
| **Storage** | 30-40GB SSD for logs + session data |
| **OpenClaw Version** | v2026.3.3 |
| **AI Model** | Z.AI / GLM-5 (via zai provider) — primary model |
| **Deployment** | systemd service (openclaw.service) |
| **User** | `claw` service user at `/var/lib/claw` |

## Architecture

Hub-and-spoke: OpenClaw Gateway at the center, channels + agents around it.

```
[User via Matrix/WhatsApp/Telegram]
         ↓
[Channel Plugin]
         ↓
[OpenClaw Gateway ws://127.0.0.1:18789]
         ↓
[Configured Agent]
         ↓
[Z.AI GLM-5 or Claude API]
         ↓
[Response streamed back]
```

## Channel Integrations

| Channel | Plugin | Status |
|---------|--------|--------|
| **Matrix** | @openclaw/matrix v2026.3.12 | ✓ Active |
| **Telegram** | via bot token | ✓ Active |
| **WhatsApp** | via QR pairing | ✓ Active |

## Matrix Integration

- **Self-hosted Matrix homeserver:** matrix.neuraledge.in
- **Element web:** element.neuraledge.in
- **Bot account:** @naveensynlex:matrix.org
- **Homeserver:** matrix-client.matrix.org (also external bridge)
- **DM Policy:** pairing (user must pair first)
- **E2EE:** Disabled (not required for this use case)
- Full Matrix whitepaper written for integration documentation

## Security Posture

### Gateway
- **Binding:** loopback (127.0.0.1) only — never 0.0.0.0
- **Port:** 18789
- **Public exposure:** None (SSH tunnel or Tailscale for admin access)

### Security Group Rules (AWS)
- SSH (port 22) locked to specific IP (`122.162.150.22/32`)
- Port 18789 NOT exposed publicly
- Outbound: all traffic allowed

### Remote Access Options
1. **SSH Tunnel** (ad-hoc): `ssh -N -L 18789:127.0.0.1:18789 openclaw@IP`
2. **Tailscale Serve** (always-on): `sudo tailscale serve https / http://127.0.0.1:18789`
3. **Nginx + SSL** (advanced, for public domain)

### Hardening Layers
- Dedicated user
- SSH lockdown
- UFW firewall
- fail2ban
- Docker with no-new-privileges, read-only, cap_drop ALL
- DM pairing + channel allowlists + mention gating

## Per-Agent Configuration

Each NEop has:
- Its own `agentId` in `openclaw.json` under `agents.<agentId>`
- Its own workspace directory with role-specific `AGENTS.md`
- Its own tool policy
- Its own model selection (can run different agents on different models)
- Subagent spawning capability

## Workspace Files (per NEop)

- `SOUL.md` — Identity, personality, ethical rules
- `AGENTS.md` — Agent instructions, responsibilities
- `MEMORY.md` — Semantic knowledge
- `HEARTBEAT.md` — Periodic check-in tasks
- `SKILL.md` files — Installed skills (12 for Neural)
- `BOOTSTRAP.md` — Startup sequence
- `TOOLS.md` — Available tool dispatch
- `memory/*.md` — Structured memory files
- `sessions/*.jsonl` — Session transcripts

## Session Management

- Transcripts appended to subagent-aware JSONL file
- Session data stored in `~/openclaw/state`
- Auto-rotation: sessions >30 days deleted weekly via cron

## Operations

### Monitoring
- Health check script (healthcheck.sh)
- Uptime, latency, error rates monitored
- AWS billing anomaly detection

### Updates
- Automated via systemd timer (update.sh)
- Docker: pull + up -d + image prune

### Logs
- Docker log rotation (weekly)
- Session transcript pruning (monthly)

## Related Tools

- **Pi Agents** — Reference SDK integration cited by OpenClaw docs
- **NeP system** — Packaged workspace configurations (AGENTS.md + SOUL.md + tool policy + skill set) dropped into extensions folder
