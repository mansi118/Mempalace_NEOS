# NEOS — The Agentic Operating System

## What NEOS Is

NEOS (NeuralEDGE OS) is a fully cloud-based operating system for the AI-native enterprise. It is the platform through which businesses deploy, collaborate with, and continuously improve digital employees that deliver measurable business outcomes.

**NEOS is NOT:**
- A chatbot
- A copilot
- A SaaS dashboard

**NEOS IS:** The operating layer that sits between a company's business operations and its AI workforce.

## The Three-Layer Stack

| Layer | Component | Purpose |
|-------|-----------|---------|
| **Gateway** | NEC (NeuralEDGE Cloud) | Desktop application — the single point of access |
| **Operating System** | NEOS | Cloud-based OS where all digital employees run, collaborate, evolve |
| **Applications** | NEOPS | Digital employees — purpose-built apps for specific business functions |

## Three Purpose-Built Apps

| App | Purpose | One-Liner |
|-----|---------|-----------|
| **QuickBuildAI** | Configuration & Deployment | "Tell us what you need. We'll build it." |
| **AgentSpace** | Workspace & Collaboration | "Where your AI workforce lives and works." |
| **NEE** | Evaluation & Improvement | "Make every digital employee smarter, every day." |

### How the Three Apps Connect

**Build (QuickBuildAI)** → A conversational AI agent interviews the user, understands the business need, configures a digital employee, sets up the AgentSpace workspace, wires integrations, and deploys — all through a guided conversation.

**Work (AgentSpace)** → The digital employee operates inside AgentSpace, a Notion-like workspace where it stores data, generates outputs, and collaborates with human team members and other digital employees through a Slack-like messaging layer.

**Improve (NEE)** → Every action is monitored by NEE. Performance data flows into evaluation dashboards. Agent memories are managed and refined. Self-improving feedback loops identify and correct undesirable behavior.

## Conceptual Architecture

```
┌─────────────────────────────────────────────────────────┐
│                        NEOS                             │
│           The AI-Native Enterprise OS                   │
│                                                         │
│  ┌───────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │  QuickBuildAI  │  │  AgentSpace  │  │     NEE      │ │
│  │                │  │              │  │              │ │
│  │  Configure     │  │  Workspace   │  │  Evaluate    │ │
│  │  Deploy        │──▶  Collaborate │──▶  Improve     │ │
│  │  Integrate     │  │  Operate     │  │  Control     │ │
│  └───────────────┘  └──────────────┘  └──────────────┘ │
│                                                         │
│  ┌─────────────────────────────────────────────────────┐│
│  │              Protocols Layer (NePs)                 ││
│  │   Standards of Operations for all Digital Employees ││
│  └─────────────────────────────────────────────────────┘│
│                                                         │
│  ┌─────────────────────────────────────────────────────┐│
│  │           Integration Gateway                       ││
│  │    Salesforce · HubSpot · Upstox · Slack · etc.     ││
│  └─────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────┘
```

## 11-Layer Architecture

NEOS is described as an 11-layer agentic OS built on the unforked **OpenClaw** runtime.

## Four Foundational NEOPS (Nervous System)

Every NEOS deployment ships with these four:

1. **System Controls** — Configure everything
2. **Company Connect** — Human-AI collaboration
3. **Company Context Library** — Give every digital employee full organizational knowledge
4. **NEE** — Make them smarter with every interaction

## Key Differentiators

1. **Pre-loaded tools** — An SDR NEop ships with its own CRM, email tools, lead scoring, outreach sequences. No need to connect external tools.
2. **Full-stack** — Agent deployment + workspace + persistent memory + self-improving skills + integrated evals + multi-agent orchestration. All in one SMB-ready platform.
3. **No competitors have this full stack** — (per internal positioning)

## Deployment Options

- **Cloud:** Default, on NeuralEDGE infrastructure
- **On-premise:** For enterprises that need it (zero external data dependencies architecture)
- **PrivatNEOS:** Private deployment tier with self-hosted models

## NEOS Frontend Stack

- Notion-clone UI design
- Built with TanStack Start
- Design tokens and component structure enforced via the `neos-frontend` skill
