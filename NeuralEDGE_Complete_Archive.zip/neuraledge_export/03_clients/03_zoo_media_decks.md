# Zoo Media — Pitch Decks & Communications

## Deck Inventory

### 1. Main Pitch Deck (HTML, 105 slides)
- **File:** `NeuralEDGE_x_ZooMedia_Pitch.html`
- **Audience:** Akhilesh Sabharwal, CTO — Zoo Media
- **Date:** February 2026
- **Format:** Scroll-snap HTML deck with glassmorphic cards, fade-up animations
- **Tone:** CTO-grade depth, consultative founder-to-founder

### 2. Akhilesh "Invisible AI" Pitch Deck (PPTX)
- **Trigger:** Akhilesh's social media post — "real ROI in 2026 comes from Invisible AI — where tech handles grunt work of media buying, allowing creative minds to focus on cultural nuance"
- **Pitched:** NEOS as Consulting product + NEOP marketplace (future rent-a-digital-employee play)
- **CTA:** Free fractional AI Audit — in-person 5hr session, starting strategy for 2-day implementation OR roadmap for 2-week Digital Employee build

### 3. Marketplace Monetization Deck (4 pages — PLAN PHASE)
- Repositions ICD project as marketplace asset
- Awaiting ML approval before execution

## Design System (NeuralEDGE Brand)

### Colors
- **Navy:** `#132F48`
- **Teal:** `#13C5B3`
- **Ice:** `#EFF4F9`

### Alternative palette seen in some decks
- `--teal: #00C9A7`
- `--dark: (dark navy)`
- `--light: (off-white)`
- `--gray: (gray body text)`

### Typography
- **Space Grotesk** — Display/headlines
- **DM Sans** — Body text
- **JetBrains Mono** — Monospace accents

### Aesthetic Directives
- Dark navy + teal
- Scroll-snap slides
- Floating orbs
- Glassmorphic cards
- Fade-up animations
- Cinematic feel

### Layout Primitives
- Two-column grid for comparisons
- Cards with hover lift (translateY -4px)
- Sticky navigation with confidential badge
- Stat rows for proof points
- FAQ accordion
- Fund table with teal highlighted totals

## Deck Suite (Full Family, built in PptxGenJS)

1. Investor Pitch Deck
2. Zoo Media Client Deck (v2 recut)
3. Tech Partners Deck
4. Consulting Firms Deck
5. Clients Deck
6. NEOS 6-Pager (build3 Bar Raiser)

## Zoo Deck Section Structure (Final)

```
SECTION 0: Cover + Identity Lock
  ├─ Hero: "Your Network Has 600 Animals. Now Give Them Superpowers."
  ├─ Subtitle: "AI Employee strategy for Zoo Media's 8 agencies"
  └─ Tags: "Prepared for Akhilesh Sabharwal, CTO — Zoo Media" | "February 2026"

SECTION 1: Problem Statement — Starting a business has never been easier to imagine and never been harder to execute

SECTION 2: The Solution — NEOS is the execution layer for the AI-native enterprise

SECTION 3: 4 Platform Pillars
  ├─ QuickBuildAI
  ├─ AgentSpace
  ├─ NEE (NeuralEDGE Evals)
  └─ Context Vault

SECTION 4: The 6 AI Employees for Zoo

SECTION 5: Platform Demo Stats
  ├─ 50–100x Faster Lead Response (Shinon)
  ├─ 7% Productivity Boost Month 1 (Shinon)
  ├─ 30 min New Lead TAT
  └─ Day 1 NEOS Self-Deployment

SECTION 6: Team (4 cards)
  ├─ YG (ASU dropout, strategy)
  ├─ Dr. Rahul Kashyap (PhD, CTO)
  ├─ Mansi Gambhir (Ex-DRDO/Samsung, Tech Lead)
  └─ +3 NEOS Consultants (Forward Deployed)

SECTION 7: Pricing — Three Ways to Begin
  ├─ Free trial (2 weeks, single AI employee)
  ├─ AI Audit (starts at ₹1.5L)
  └─ Full engagement (starts at ₹25L for private AI)

SECTION 8: ICD Deep-Dive (Priya at FoxyMoron story)

SECTION 9: Close + Appendix
```

## Communication Drafts Used

### Cold outreach framing
- Led with Akhilesh's own "Invisible AI" language
- "We'd love to help you evolve Zoo Media into India's most intelligent agency network"
- Offered free 5hr AI Audit as low-commitment entry

### Marketplace follow-up framing
- "Warm, founder-to-founder, commercial"
- NOT a cold pitch — a "here's the money on the table" conversation
- "The ICD we're building together isn't just for Zoo Media. It's a product. Other agencies rent it. You get paid."

## Zoo Expo Flyer

ML also requested an EXPO flyer design for NeuralEDGE. Details gathered through question-based input.

## Key Personalizations Applied to Zoo Deck

1. ✅ Addressed as 8-agency network (not single agency)
2. ✅ Named all 8 specialist agencies in the network
3. ✅ Referenced Akhilesh's "Marketing Technology Organization" mandate
4. ✅ Used Zoo's own stats (600 people, 2,500+ brands, 500+ awards, 5 cities)
5. ✅ Named their big-brand clients (Netflix, L'Oréal, Amazon, etc.)
6. ✅ ICD story uses "Priya at FoxyMoron" — specific and real
7. ✅ Hindi/regional language support called out (Naya Bharat initiative)
