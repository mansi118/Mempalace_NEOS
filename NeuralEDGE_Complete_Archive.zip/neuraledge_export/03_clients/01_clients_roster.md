# Clients & Prospects Roster

## Active Clients

| Client | Status | Details |
|--------|--------|---------|
| **Zoo Media** | Most active | India's largest independent agency network. See `02_zoo_media_full.md` for full dossier. |
| **Breakfree** | Active | Active client engagement |
| **Von Albert** | Active | Berlin luxury real estate client (international) |
| **Yoga Studio Chain** | Active | Recon SDR agent deployed for US/GB market leads (Apify stack) |
| **Shinon Global** | Flagship | Primary traction proof point / case study. Enterprise deployment. |
| **Unborred Club** | Historical | Archived engagement |

## Shinon Global — Traction Proof Points

- **Lead Response TAT:** 24–48 hours → 30 minutes (50–100x improvement)
- **Chief of Staff NEop:** 7% individual productivity boost in Month 1
- Full AI-native transformation engagement
- Primary case study for build3 Bar Raiser and investor decks

## Stat Bar (used in decks)

| 50–100x | 7% | 30 min | Day 1 |
|---------|-----|--------|-------|
| FASTER LEAD RESPONSE | PRODUCTIVITY BOOST (MONTH 1) | NEW LEAD TAT | NEOS SELF-DEPLOYMENT |

## Prospects & Pipeline (from past chats)

- **Zoo Media** — ICD delivered, marketplace listing pitch in plan phase
- **The Nuural Network / Crack'd** — Pitch deck produced
- **Asymmetrique** — Pitch deck produced
- **Vibe Theory** — Pitch deck produced (~₹4.5L engagement range)
- **build3** — Pitched to Varun Chawla's startup studio as productization partner (see `07_legal_and_fundraising/03_build3_bar_raiser.md`)

## Key Stakeholder Map

| Client | Contact | Role |
|--------|---------|------|
| Zoo Media | Akhilesh Sabharwal | CTO |
| Zoo Media | Pratik Gupta | Co-Founder |
| Zoo Media | Suveer Bajaj | Co-Founder |

## Client Engagement Lifecycle

```
Lead Qualified (Recon/Aria)
    ↓
Discovery Call (Scout research)
    ↓
NDA Signed
    ↓
AI Audit (Phase 1)
    ↓
Proposal
    ↓
MSA + SOW Executed
    ↓
Tier 1 Build (1–2 NEops, Month 1)
    ↓
ROI Proven
    ↓
Tier 2 Upsell (Full NEOS)
    ↓
Quarterly Retainer Reassessment
```

## GTM Targets

- **10 net-new clients/month**
- **30 clients in next 3 months**
- **Revenue Goal:** ₹3 Crore MRR at ₹5L average retainer
- Current team services up to 100 clients without new hires
