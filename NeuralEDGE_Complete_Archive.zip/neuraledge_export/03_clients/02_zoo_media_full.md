# Zoo Media — Complete Engagement Dossier

## Overview

**Zoo Media is India's largest independent agency network** and NeuralEDGE's most active client/prospect.

## Company Fundamentals

- **Type:** Independent agency network (not a single agency)
- **Headcount:** 600+ people
- **Agencies:** 8 specialist agencies under one network
- **Offices:** 5 global cities (MUM / DEL / BLR / DXB / NYC)
- **Brands Served:** 2,500+
- **Awards:** 500+
- **Notable Clients:** Netflix, L'Oréal, Amazon, P&G, HUL, Burger King, Swiggy, ICC World Cup

## The 8 Specialist Agencies

1. **FoxyMoron** — Full-funnel brand campaigns
2. **Pollen** — Influencer marketing
3. **The Rabbit Hole (TRH)** — Video content
4. **Starter Labs** — D2C content at scale
5. **TCM** — Sports content
6. **XP&D** — Experiences and events
7. **Phosphene** — (specialist agency in network)
8. **Metaform** — (specialist agency in network)

## Key Stakeholders

| Name | Role |
|------|------|
| **Akhilesh Sabharwal** | CTO — primary NeuralEDGE contact |
| **Pratik Gupta** | Co-Founder |
| **Suveer Bajaj** | Co-Founder |

### Akhilesh's Strategic Mandate
- Evolving Zoo Media into a "Marketing Technology Organization"
- Integrating AI/ML across the network
- Public stance: "Invisible AI" — AI handles grunt work of media buying so creative minds focus on cultural nuance (from his social post)

## The Central Narrative (Revenue Per Employee)

The 105-slide Zoo Media pitch deck was built around **Revenue Per Employee** as the single highest-leverage metric. Every other point connects back to this.

**Core Frame:** "Your Network Has 600 Animals. Now Give Them Superpowers."

**Subtitle:** "A bespoke AI Employee strategy to supercharge Zoo Media's 8 agencies — turning India's largest independent network into India's most intelligent one."

## 6 AI Employees Designed for Zoo Media

| NEop | Purpose |
|------|---------|
| **CampaignIQ** | Cross-agency performance analytics (unified dashboards across all 8 agencies) |
| **ContentForge** | Copy & content with Hindi/regional support for Naya Bharat initiative |
| **InsightRadar** | Market & cultural intelligence for FoxyMoron, Pollen, Starter Labs |
| **PollenMatch** | Influencer discovery with fraud detection (for Pollen agency) |
| **PitchBot** | New business prep across the network |
| **OpsHive** | Multi-office, multi-agency workflow management |

## Pricing Options Offered to Zoo Media

Three entry points offered to Akhilesh:

1. **Free Trial** — Single AI employee free for 2 weeks
2. **AI Audit** — Starts at ₹1.5 lakhs
3. **Full Engagement** — Starts at ₹25 lakhs (for private AI models, one-time investment size)

## The Pitch Deck (105 Slides)

### Deck Structure
1. **Cover + Hook** (5 slides) — Warm open, identity lock
2. **The Zoo Media Mirror** (8 slides) — Reflect their own ambition
3. **The Industry Problem** (12 slides) — Frame the creative-vs-grunt gap
4. **The NEop Paradigm** (15 slides) — Collapse "AI = tools" → "AI = employees that use tools for you"
5. **NEOS Platform** (15 slides) — CTO-grade depth (Context Vault chunking, memory architecture, MCP queries)
6. **ICD NEop for Zoo** (12 slides) — "Priya at FoxyMoron" story with before/after
7. **75-Day Journey** (13 slides) — Milestone-by-milestone transparency
8. **The Math** (8 slides) — Salary comparison (Zerodha principle, not abstract ROI %)
9. **Partnership** (5 slides) — "We build together"
10. **Close + Appendix** (12 slides) — Clear next step, NEOP Marketplace teaser

### Writing Frameworks Applied
- Dune-level micro-detail for NEop demonstrations
- Himish pattern (named protagonist, specific workflows, before/after)
- Tribal signaling for partnership sections
- Trust architecture for journey slides

## ICD NEop — The First Delivery

**See `04_zoo_icd_neop.md` for full build details.**

Summary: Image Content Director NEop delivered as first build. Handles content creation across 2,500+ brand accounts.

## Before/After Story Template (Priya at FoxyMoron)

### Before ICD
- Priya manages 12 brand accounts
- Monday: 3 hrs reviewing briefs
- Tuesday: 2 hrs creating content matrices
- Wednesday: 4 hrs revisions
- Thursday: 2 hrs performance reports
- Friday: Only 3 hrs creative strategy
- **Total creative time: 15% of week**

### After ICD
- Monday 9am: ICD has parsed all 12 briefs overnight, created specs, generated first-draft visual directions
- Priya reviews, approves, adjusts — done by 10:30am
- Tuesday: ICD handles multi-format adaptations
- Wednesday: ICD runs QA, Priya reviews only flagged items
- Thursday: Reports auto-generated
- Friday: Entire day on creative strategy
- **Total creative time: 60% of week**

### The Priya Multiplier
- Before: 12 accounts, 15% creative time
- After: 12 accounts, 60% creative time — OR 30 accounts at same quality
- Multiplied across 600 people = the Revenue Per Employee shift

## ICD Across the Zoo Network (Adaptation Matrix)

| Agency | ICD Specialization |
|--------|-------------------|
| FoxyMoron | Full-funnel content for brand campaigns |
| Pollen | Influencer content QA and brief generation |
| The Rabbit Hole | Video content thumbnail and metadata optimization |
| Starter Labs | D2C content at scale |
| TCM | Sports content with real-time event adaptation |

**One NEop. Eight agencies. Customized per specialty.**

## NEOP Marketplace Pitch to Zoo Media

**4-page follow-up document (PLAN PHASE — awaiting ML approval):**

### Page 1: Hook
- **Headline:** Your Content Expertise, Productised
- **Subtitle:** How the Zoo Media ICD NEop earns royalties on the NEOP Marketplace
- Core message: Built by Zoo Media's expertise, scaled by NeuralEDGE's platform

### Page 2: The Marketplace
- Where the ICD NEop lives and earns

### Page 3: The Money
- Exactly how royalties work + example numbers
- 60% NeuralEDGE / 40% Zoo Media split

### Page 4: Next Steps
- What happens now

## Memory Palace — Zoo Media Sub-Wing (from CORTEX-PALACE)

```
Sub-Wing: Zoo Media (Active)
├── Decisions Hall
│   ├── Room: Engagement Scope
│   │   └── ICD NEop engagement, approved scope, exclusions
│   └── Room: Content Strategy
│       └── Strategic direction for Akhilesh Sabharwal's team
├── Facts Hall
│   ├── Room: Contract & Budget
│   │   └── SOW terms, pricing, payment schedule, MSA ref
│   ├── Room: Deliverables
│   │   └── What's promised, what's delivered, timelines
│   ├── Room: Contacts
│   │   └── Akhilesh Sabharwal, other stakeholders, roles
│   └── Room: Client Environment
│       └── Their tech stack, tools, processes, constraints
│       └── Which NEOps deployed: ICD
│       └── Which NePs active for this client
├── Conversations Hall
│   ├── Room: Meeting Notes
│   └── Room: Async Threads
├── Tasks Hall
│   ├── Room: Active Deliverables
│   └── Room: Pending Approvals
└── Lessons Hall
    ├── Room: What Worked
    └── Room: What Failed
```

## File Naming Convention for Zoo Deliverables

- `NeuralEDGE_x_ZooMedia_Pitch.html` — Main pitch deck (HTML version)
- `zoo-deck.html` — Working file
- References in past decks: "Prepared for Akhilesh Sabharwal, CTO — Zoo Media"

## Key Deck Cover Specs

- NeuralEDGE × Zoo Media co-branded cover
- Navy + teal color scheme (NeuralEDGE brand)
- Date: February 2026 for initial pitch, March 2026 for marketplace follow-up
- Tagline: "600 people, 8 agencies, 5 cities, 2,500+ brands served. AI Employees don't replace the animals — they give every Fox, Rabbit, Bee, and Chameleon in the Zoo superhuman capabilities."
