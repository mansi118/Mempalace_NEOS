# ICD NEop — The First Zoo Media Build

## Identity

- **Name:** ICD (Image Content Director)
- **Role:** Client-facing content creation NEop
- **Deployed For:** Zoo Media network
- **Scope:** Content across 2,500+ brand accounts

## Positioning

> "ICD doesn't replace your content creators. It handles the 80% of content work that isn't creative strategy — so your creators can focus on the 20% that wins awards."

## 6 Core Capabilities

### 1. Brief Interpretation
- Reads client briefs
- Extracts requirements
- Creates content specifications
- Flags ambiguities or missing info

### 2. Visual Direction
- Generates image concepts
- Creates mood boards
- Compiles style references
- Aligns with brand guidelines

### 3. Content QA
- Reviews every piece against brand guidelines
- Checks tone, messaging, visual consistency
- Flags deviations for human review

### 4. Multi-format Adaptation
- One concept → Instagram, LinkedIn, Twitter, Stories, Reels
- Resizes and reformats automatically
- Adapts copy for platform conventions

### 5. Performance Learning
- Tracks which content performs best
- Feeds performance data back into future briefs
- Self-improving loop via NePs

### 6. Client Reporting
- Auto-generates performance reports per brand
- Formatted to Zoo Media / agency standards
- Saves hours of weekly compilation time

## Agency-Specific Adaptations

ICD is one NEop but configured differently per Zoo agency:

| Agency | Specialization |
|--------|---------------|
| **FoxyMoron** | Full-funnel content for brand campaigns |
| **Pollen** | Influencer content QA + brief generation |
| **The Rabbit Hole** | Video thumbnail + metadata optimization |
| **Starter Labs** | D2C content at scale |
| **TCM** | Sports content with real-time event adaptation |

**One NEop. Eight agencies. Customized per specialty.**

## The "Priya" Story (Demonstration Narrative)

### Before ICD
Priya is a Content Manager at FoxyMoron managing 12 brand accounts.

**Weekly breakdown:**
- **Monday (3 hrs):** Reviewing briefs from clients
- **Tuesday (2 hrs):** Creating content matrices
- **Wednesday (4 hrs):** Back-and-forth revisions
- **Thursday (2 hrs):** Compiling performance reports
- **Friday (3 hrs):** Finally doing creative strategy

**Total creative time: 15% of her week**

### After ICD (Priya's New Monday)
- **Monday 9am:** ICD has already parsed all 12 briefs overnight, created content specs, and generated first-draft visual directions
- Priya reviews, approves, adjusts — done by 10:30am
- **Tuesday:** ICD handles all multi-format adaptations
- **Wednesday:** ICD runs QA against brand guidelines — Priya only reviews flagged items
- **Thursday:** Reports auto-generated and sent
- **Friday:** Priya spends the ENTIRE day on creative strategy

**Total creative time: 60% of her week**

### The Priya Multiplier
- **Before:** 12 accounts, 15% creative time
- **After (Option A):** 12 accounts, 60% creative time (quality increases)
- **After (Option B):** 30 accounts at same creative quality (output 2.5x)
- **Multiplied across 600 people = the Revenue Per Employee shift**

## Why ICD First

Strategic rationale for ICD as Tier 1 build for Zoo:

1. **High volume use case** — content ops run daily across all agencies
2. **Measurable outcomes** — time saved, output velocity, QA consistency
3. **Creative not replaced** — humans retain strategic/judgment work (low political friction)
4. **Cross-agency portability** — proves NEop can serve multiple specialties
5. **Marketplace candidate** — other agencies will pay to rent this

## Marketplace Future (Royalty Play)

ICD is positioned as Zoo's first **rentable NEop asset** on the NEOP Marketplace.

**Revenue structure:**
- 60% NeuralEDGE / 40% Zoo Media
- Every time another agency rents ICD, Zoo earns royalty
- Built once, earns forever

**Pitch angle:** Reframe engagement from "cost of AI consulting" to "building a royalty-generating asset."

## Build Architecture (inferred from conversations)

- Built on OpenClaw runtime
- Uses Context Vault for brand knowledge per Zoo client
- NeP-based self-improvement (learns what creative works)
- Tool stack likely includes: image generation APIs, platform adapters (Instagram/LinkedIn/etc.), brand guideline vector stores

## Status

- ✅ Delivered to Zoo Media
- 🔄 Active performance learning in production
- 📋 Marketplace listing in plan phase (awaiting ML approval)
