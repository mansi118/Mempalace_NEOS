# Conversation Index

All conversations found during the export, organized by topic. Use these URLs to jump to the original chat (must be logged in to claude.ai).

**Link format:** `https://claude.ai/chat/{uri}`

---

## Company & Vision

| Topic | URL | Last Updated |
|-------|-----|--------------|
| Synlex Technologies Pitch Deck Prompt | https://claude.ai/chat/65e82da3-8975-4fc9-8f9b-bec734eb7471 | 2025-05-30 |
| Understanding NeuralEDGE's product vision | https://claude.ai/chat/44610552-68ad-4564-972e-7669e5207da3 | 2026-03-09 |
| Creating a markdown file from memories (NeuralEDGE Complete.md) | https://claude.ai/chat/14d97e53-6ecb-4814-be54-5df960c75235 | 2026-04-09 |
| Refining Neo's vision document | https://claude.ai/chat/7ffcf76d-113e-4cd2-8e51-05b55202df79 | 2026-02-20 |

## NEOS Platform & NEops

| Topic | URL | Last Updated |
|-------|-----|--------------|
| NEOS implementation plan and system design | https://claude.ai/chat/e3e03879-2bdd-4d64-9fdc-4a48f40bbee6 | 2026-02-14 |
| NEOS vision document and architecture | https://claude.ai/chat/886c0fdd-51e7-48a1-9fa3-897699fb318a | 2026-02-14 |
| NEOPS system design and architecture | https://claude.ai/chat/3f770c9c-be74-4d0b-913c-9a00b3a0a102 | 2026-03-13 |
| NEOS chief of staff workflow and tools | https://claude.ai/chat/09a6beff-8f57-4b1d-8439-a13b2e478a97 | 2026-03-18 |
| Agent design for NEOS using OpenClaw | https://claude.ai/chat/f8b96b11-e071-426c-8368-42eaf7e1ce0d | 2026-02-28 |
| OpenClaw hub-and-spoke architecture explained | https://claude.ai/chat/b677381e-d08a-4394-8464-3be9fbd056ff | 2026-03-07 |
| Converting tool to CLI for NEops integration | https://claude.ai/chat/07e5b503-4084-49d3-820c-2ad6d89968b3 | 2026-03-03 |

## Infrastructure & OpenClaw

| Topic | URL | Last Updated |
|-------|-----|--------------|
| OpenClaw files and workspace configuration (Matrix whitepaper) | https://claude.ai/chat/4effc421-1a7b-40c9-85af-349a46f84be8 | 2026-03-17 |
| Secure deployment of OpenClaw documentation | https://claude.ai/chat/5777622d-22a8-4c70-b7f5-230bb2e728f0 | 2026-02-13 |

## Memory & Context Vault

| Topic | URL | Last Updated |
|-------|-----|--------------|
| Memory palace architecture for NEOS (CORTEX-PALACE v1→v3) | https://claude.ai/chat/ce145780-966f-44a0-aaf2-a256a7cdf6f6 | 2026-04-16 |
| Context vault research and implementation resources | https://claude.ai/chat/7c17743d-a0fe-469e-995f-ba9487fcf333 | 2026-04-13 |
| Building context vault architecture from scratch | https://claude.ai/chat/ec552f1c-c8f8-4cb5-9a5b-584ed7cf7efa | 2026-04-04 |
| MemPalace AI memory system for agents | https://claude.ai/chat/4f6128a4-7ae4-436b-9e1a-cae14b3a0822 | 2026-04-14 |

## Zoo Media

| Topic | URL | Last Updated |
|-------|-----|--------------|
| Pitch deck for Zoo Media's invisible AI strategy | https://claude.ai/chat/3d291d67-5d72-4877-9fc9-48151ea21e41 | 2026-02-23 |
| AI employees with physical intelligence capabilities (Zoo deck) | https://claude.ai/chat/1c23fd03-cbc5-4e77-bcc9-87e156c22f6f | 2026-02-11 |
| Zoo Media AI-native transformation and productization strategy | https://claude.ai/chat/789665d3-fb59-40fb-b6e9-5ffbbe44fc0e | 2026-03-24 |
| Zoo-ICD NEop marketplace monetization plan | https://claude.ai/chat/3f7ab212-1b75-4d88-a54c-7d8150f8c3b5 | 2026-03-31 |

## GTM & Sales

| Topic | URL | Last Updated |
|-------|-----|--------------|
| Building GTM engine for NEOS consulting services | https://claude.ai/chat/279e7fcd-0702-4dbd-b405-012cc9113cb1 | 2026-03-20 |
| Defining NeuralEDGE's ideal customer profile | https://claude.ai/chat/2ac664e5-a03c-4ad3-9d08-a3f7baae2188 | 2026-03-22 |
| Identifying the right industry for AI disruption reports | https://claude.ai/chat/d6eb2352-5488-4ef6-8ba6-71102ec1d615 | 2025-11-26 |
| Market intelligence & GTM research agent prompt | https://claude.ai/chat/ec91fb47-0e6d-4edb-b1a0-4363b7cfa8c2 | 2025-09-07 |

## B2B Intelligence (NEXUS / ALTE)

| Topic | URL | Last Updated |
|-------|-----|--------------|
| Multi-platform company intelligence graph database | https://claude.ai/chat/543d0efd-b473-488d-9a6d-2f2cc65919d4 | 2026-03-23 |

## Products & Tools

| Topic | URL | Last Updated |
|-------|-----|--------------|
| Customer Connect Emma — Project product overview | https://claude.ai/chat/beb8beca-290e-4cf4-88d9-e334c869b12b | 2025-10-18 |
| NeuralEDGE premium website rebuild | https://claude.ai/chat/6be555dc-ee64-4372-b011-8ece5adb9971 | 2026-02-04 |

## Legal & Fundraising

| Topic | URL | Last Updated |
|-------|-----|--------------|
| Legal documents for consulting engagements | https://claude.ai/chat/0cd3b1f6-885c-4319-8944-b419c587c55d | 2026-04-05 |
| HTML file screenshot request (NEOS 6-Pager build3) | https://claude.ai/chat/d4c363dd-e60b-4448-a28e-3c48b330504c | 2026-03-27 |
| build3 drive search / edits | https://claude.ai/chat/32055bcf-c942-4ce9-bb40-4c179baf9692 | 2026-03-21 |
| Service business productization and marketplace strategy | https://claude.ai/chat/f29807f0-e7dd-4662-9290-a9890aae5ee4 | 2026-03-23 |

---

## How to Use This Index

1. Click any URL to open the original chat (must be logged into claude.ai)
2. If the link doesn't work, copy the UUID at the end and navigate manually
3. Some chats span multiple topics — they're listed under the primary one

## Notes on Completeness

- This index is generated from my conversation search results on April 19, 2026
- Not every chat ML has had with Claude is listed here — only those that surfaced in topic searches for: NeuralEDGE, Zoo Media, NEOS, CORTEX, OpenClaw, NEops, GTM, and related topics
- For the complete raw conversation archive, use **Settings → Privacy → Export Data** on claude.ai
