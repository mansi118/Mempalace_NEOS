# Customer Connect — Emma WhatsApp Shopping Agent

## What Emma Is

Emma is a **WhatsApp-native e-commerce assistant** that handles the complete shopping journey for customers directly inside WhatsApp — no app download required.

## Positioning

> "A virtual sales assistant that can serve unlimited customers simultaneously, providing personalized attention to each one."

## Core Capabilities

### 1. Product Discovery
- Search by name, brand, category
- Smart recommendations based on browsing/purchase history
- Popular items for new customers
- Product details (price, brand, images, specs)

### 2. Shopping Cart Management
- Add to cart
- View cart (quantities + total)
- Update quantities
- Remove items
- Clear cart
- Real-time price calculation
- Tax + shipping calculations
- Discount code application
- Cart persists 24 hours

### 3. Visual Shopping Experience
- Product images displayed in-chat
- **Virtual try-on** — customer uploads photo, AI shows how clothing would look
- Image-based search (upload photo → find similar products)
- Supported items: shirts, t-shirts, dresses, jackets/outerwear

### 4. Personalized Experience
- 7-day conversation memory (can leave and return)
- Shopping history tracking
- Tailored recommendations
- Continuous context across sessions

### 5. Order Management
- Guided checkout
- Multiple saved addresses
- Payment method selection
- Delivery options
- Order placement with confirmation
- Real-time order status
- Delivery tracking
- Expected delivery date
- Delivery notifications
- Order history

### 6. Payment Options
- Cash on Delivery (COD)
- UPI
- Credit/Debit cards
- Digital wallets
- Net banking

### 7. Customer Service
- Product information Q&A
- Shipping details
- Return & exchange policy
- Size guide assistance
- Care instructions
- Order status updates
- FAQ responses
- Complaint registration
- Feedback submission
- Human agent escalation

### 8. Smart Features
- Natural conversational language (casual OK)
- Multi-request handling in one message
- Context-aware responses
- New product alerts
- Sale notifications
- Price drop alerts
- Back-in-stock notifications

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Agent Framework** | Strands (AWS Strands SDK) |
| **State / Cart** | Redis |
| **Product Catalog** | MongoDB |
| **User Data** | Supabase |
| **Payments** | Razorpay |
| **Recommendations** | AWS Personalize |
| **Virtual Try-On** | AI model (image generation) |
| **Channel** | WhatsApp Business API |

## Sample Conversation Flow

```
Customer: Hi
Emma: Hello! Welcome to [Your Store]!
      I'm Emma, your personal shopping assistant.
      How can I help you today?

Customer: Show me shirts
Emma: [Shows product images with prices]
      Here are some popular shirts:
      1. Blue Formal Shirt - ₹899
      2. White Cotton Shirt - ₹799
      3. [...]

Customer: Try on #1
Emma: Please upload a photo of yourself.
[Customer uploads]
Emma: [Returns image of customer wearing the shirt]
      Here's how the Blue Formal Shirt looks on you!

Customer: Add to cart size M
Emma: Added! Your cart now has 1 item worth ₹899.

Customer: Checkout
Emma: [Guides through delivery address, payment method, confirmation]
```

## Business Benefits

### For Customers
- Shop anytime, anywhere via WhatsApp
- Personalized recommendations
- See products visually before buying
- Easy cart management
- Quick product Q&A

### For Business
- Reduce customer service staff need
- Handle unlimited concurrent customers
- 24/7 sales coverage (never miss a sale)
- Automatic customer preference data collection
- Lower customer acquisition costs (WhatsApp already installed)

## Memory Architecture

- **Short-term:** Redis for active session / cart state
- **Medium-term:** 7-day conversation context
- **Long-term:** Customer profile in Supabase with purchase history, preferences, sizes, budget

## Why WhatsApp-Native (not app)

1. **Zero install friction** — customer already has WhatsApp
2. **Higher engagement** — conversational UX beats tapping through menus
3. **Lower CAC** — no app download ads needed
4. **India-first channel** — WhatsApp is the dominant comm channel
5. **Always-on notifications** — push delivery without permissions dance

## Deployment Status

- Heavily developed and tested
- Demo-ready
- Stack validated in production-like environment

## Target Use Case

D2C brands / small-to-mid retailers who:
- Sell via Instagram or direct
- Don't have bandwidth for dedicated ecom app
- Want conversational commerce
- Already use WhatsApp Business
- Need to handle 100s–1000s of daily queries

## Relationship to NEOS / NEops

Emma is a **NEop in the Customer Connect category** — one of the named NEops in the catalog. It's the flagship demo NEop for B2C/retail ICP prospects.

## Future Enhancements (pipeline)

- Multi-language support (Hindi, regional languages)
- Voice message support
- WhatsApp Status integration for offers
- Loyalty program integration
- Group order support
- Subscription commerce
