# NEXUS & ALTE — B2B Intelligence Platform

## The Two Halves

NEXUS and ALTE are complementary systems designed to give NeuralEDGE complete B2B sales intelligence.

| | ALTE | NEXUS |
|---|---|---|
| **Unit of intelligence** | A person | A company |
| **Primary output** | Confidence-scored JSON profile | Neo4j org graph |
| **Depth** | Deep (6 pipeline stages, 8 data blocks, relationship mapping, monitoring) | Broad (company-wide, multi-source, pitch-oriented) |
| **Context adaptation** | 6 modes — sales, investor, meeting prep, etc. | Single mode — pitch generation |
| **Monitoring** | 3-tier, built-in, delta profiling | On-demand refresh only |

## NEXUS — Company Intelligence

### Purpose
Autonomous org intelligence system for B2B sales targeting. Gives a whole image of an organization to effectively pitch products.

### Use Cases
- Sales prospecting (Recon-style)
- Investor due diligence
- Competitive intelligence

### Trigger Model
Two-phase:

**Phase 1: Discovery**
- Input: Criteria (e.g., "marketing companies with 50–200 employees, ₹50Cr+ revenue")
- Output: List of qualified target companies

**Phase 2: Deep Research**
- Input: Discovered company names / URLs
- Output: Complete Neo4j graph node with all public info

### Data Sources
- LinkedIn (company + people)
- Substack / blogs
- News & press releases
- Websites + job postings

### Job Postings = Signal Gold
- 5 "Sales Ops" roles open → their CRM is broken
- "AI Engineer" roles → they're building in-house (harder sell or better sell)
- Jobs Agent extracts these signals automatically

### Graph Schema (Neo4j)
- **Entities:** Company, Person, Product, Market, Event, Job
- **Relationships:** works_at, located_in, sells_to, competes_with, hired_for
- **Properties:** Revenue, employee count, tech stack, growth signals

### Deliverable Options
1. Neo4j graph queryable manually
2. Dashboard UI on top of graph
3. AI reads graph + auto-generates pitch
4. Full pipeline (graph + UI + AI pitch)

### Scale Target
Not 10, not 10,000 — mid-range initially. Architecture designed to scale.

### NEXUS is Internal Tool
- Primary: NeuralEDGE internal tool for Recon/NEOS
- Secondary: Future standalone product/license opportunity

### Build Priority (Sprint 1)
- Neo4j schema + Discovery Agent
- Code delivered via OpenClaw

## ALTE — Person Intelligence

### Purpose
Deep person-level dossiers — the "fill in the stub" agent for NEXUS's Person nodes.

### 6 Pipeline Stages
(Inferred from architecture doc)
1. Identity resolution
2. Multi-source data aggregation
3. Deduplication / conflict resolution
4. Behavioral signal extraction
5. Confidence scoring
6. Profile assembly

### 8 Data Blocks
Each profile has 8 structured blocks covering:
- Basic identity
- Career history
- Current role + context
- Network / relationships
- Communication preferences
- Behavioral patterns
- Public signals / content
- Prediction vectors

### 6 Context Modes
ALTE adapts output for:
1. **Sales** — pitch angles, objection predictions
2. **Investor** — diligence points, track record
3. **Meeting prep** — likely questions, personality read
4. **Networking** — shared interests, warm connection paths
5. **Hiring** — skills verification, cultural fit
6. **Competitive intel** — movement signals

### 3-Tier Monitoring
- **Tier 1:** High-priority contacts, daily refresh
- **Tier 2:** Medium-priority, weekly refresh
- **Tier 3:** Low-priority, monthly refresh with delta profiling (only update if changed)

### Data Source Policy
- NEXUS: free sources only (scraping-based)
- ALTE: open question — paid APIs worth it for people data?
  - Options: PDL, Apollo, Hunter, Proxycurl
  - Likely: paid for Tier 1 contacts, free for Tier 2/3

## NEXUS ↔ ALTE Integration

**The Integration Point (Clean):**

NEXUS's `(:Person)` node is essentially a **stub** — name, title, LinkedIn URL.
ALTE is what fills it in.

```
NEXUS discovers target company
  → Identifies decision makers (Person stubs)
    → For each Person stub:
      → alte_profile() called
        → ALTE returns full dossier
          → Full profile stored on NEXUS Person node
            → Pitch Agent reads ALTE profiles, not bare stubs
```

## Integration Architecture

```
┌────────────────────┐
│  ICP Criteria      │ (user input)
└─────────┬──────────┘
          ↓
┌────────────────────┐
│  NEXUS Discovery   │
│  (qualified cos)   │
└─────────┬──────────┘
          ↓
┌────────────────────┐
│  NEXUS Deep Graph  │
│  (company KG)      │
└─────────┬──────────┘
          ↓ person stubs
┌────────────────────┐
│  ALTE              │
│  (full profiles)   │
└─────────┬──────────┘
          ↓
┌────────────────────┐
│  Pitch Agent       │
│  (reads graph)     │
└─────────┬──────────┘
          ↓
┌────────────────────┐
│  Generated Pitch   │
│  (in AgentSpace)   │
└────────────────────┘
```

## Build Priority Order

Open decision:
- **Option A:** NEXUS (company graph) → ALTE (people layer) → Integration
- **Option B:** ALTE first since it's already spec'd to v1.1

## Sprint 1 Scope

- Neo4j schema design + Cypher file
- Discovery Agent code for OpenClaw
- Basic graph population pipeline
- Minimal CRUD for graph operations

## Future Product Potential

Both NEXUS and ALTE can be productized:
- License to other B2B sales teams
- NEOP Marketplace listing
- SaaS play once proven internally

## Questions Open for Decision

1. Same free-only constraint for ALTE as NEXUS? Or paid APIs allowed?
2. Build priority: NEXUS first, ALTE first, or parallel?
3. Dashboard UI: build now or phase later?
4. Scale: 10 initial companies, or design for 10,000 from day 1?
