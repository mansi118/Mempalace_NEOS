# Axe / Axe Cortex — The Self-Improving Content Engine

## What Axe Is

Axe (also referenced as **Axe Cortex**) is NeuralEDGE's marketing content NEop — a self-improving agent that learns what content works and continuously optimizes itself.

## Inspiration
Modeled on **Chroma's Context-1** paradigm — but adapted for production content workflows with NeP-based self-optimization.

## Core Stack

| Layer | Tech |
|-------|------|
| **Framework** | AWS Strands SDK |
| **Backend** | Convex |
| **Memory** | Context Vault (GTM + R&D wings) |
| **Self-Improvement** | NeP (NeuralEDGE Protocol) |

## Primary Responsibilities

### Content Generation
- LinkedIn thought leadership posts
- Blog articles
- Social media posts
- Email sequences
- Ad copy
- Case studies

### Content Performance Tracking
- Which posts drove engagement
- Which topics converted
- Best publish times per audience
- Format performance (carousel vs video vs text)
- Headline A/B testing

### Self-Optimization Loop
```
1. Generate content (using current NeP)
2. Publish
3. Track performance signals
4. Feed data back into Context Vault → GTM Wing → Lessons Hall
5. Reflector agent identifies patterns
6. Curator agent updates NeP
7. Next content generation uses improved NeP
```

## NeuralEDGE Internal Use Case

Axe runs NeuralEDGE's own marketing:
- LinkedIn presence for ML
- Content pillars supporting GTM
- Case study production (Shinon, Zoo)
- Investor-facing content

## External Client Use Case

Can be deployed into client agencies (like Zoo Media, Crack'd, Asymmetrique) for their own marketing:
- Brand-specific tone learning
- Client style guide adherence
- Multi-format content adaptation
- Performance reporting per client

## Key Metrics Tracked

| Metric | Purpose |
|--------|---------|
| Engagement rate | Quality signal |
| Click-through rate | Intent signal |
| Conversion rate | Revenue signal |
| Reach / impressions | Distribution health |
| Comment sentiment | Brand reception |
| Save rate | Content durability |

## Content Pillars (NeuralEDGE internal)

1. **Strategy** — AI transformation thinking, mental models
2. **Implementation** — How-to guides, technical patterns
3. **Industry Trends** — What's changing in AI, agentic systems
4. **Case Studies** — Client wins (Shinon, Zoo)
5. **Philosophy** — YG's vision for abundance through AI

## Planned Blog Topics (fed by Axe)
- "The 80% Promise: How to Identify What to Automate First"
- "Digital Employees vs. Chatbots: Understanding the Difference"
- "Why Knowledge Retention is the Hidden ROI of AI"
- "Building AI-Native Operations: A COO's Guide"

## Budget Allocation

From ₹25L build3 raise: **₹6L to Axe content engine fuel**
- Goes toward distribution, not creation (Axe creates for free on NEOS)
- Amplification on LinkedIn, paid boosts, production of social proof assets

## Relationship to NE-GTM

Axe is one of the sub-agents under **NE-GTM** (Go-to-Market NEop):

```
NE-GTM (orchestrator)
├── Recon SDR      — outbound prospecting
├── Axe Cortex     — content drafting, campaigns, performance optimization
├── NetworkIQ      — relationship mapping
└── StrategyIQ     — GTM strategy iteration
```

## Memory Access

Axe primarily reads/writes to:
- **GTM Wing** → Content Library (Facts Hall)
- **GTM Wing** → Content Lessons (Lessons Hall)
- **R&D Wing** → Lessons (for topic freshness)
- **Clients Wing** → client-specific brand preferences (when deployed externally)

## Sub-Agent Registry (per CORTEX-PALACE)
- **Recon** — competitive intelligence, market research, trends
- **Alte** — content drafting, campaigns, performance optimization
- (Note: "Alte" may refer to Axe Cortex here — there's some naming overlap)

## NeP-Based Self-Optimization Example

```
Initial NeP: "Post LinkedIn thought leadership Mon/Wed/Fri at 9am IST"

After 30 days, Lessons Hall shows:
- Tuesday posts got 40% more engagement
- 11am posts outperform 9am by 25%
- Carousel format beats text posts 3:1

Curator promotes pattern → NeP updated:
"Post LinkedIn thought leadership Tue/Thu/Sat at 11am IST,
prefer carousel format for tactical content."

Axe starts following updated NeP automatically. No human tuning.
```

## Integration with Other Systems

- **Reads from:** Context Vault (research, past content performance)
- **Writes to:** Platform publishing (LinkedIn, blog, etc.)
- **Triggers:** Scheduled (via HEARTBEAT.md) + on-demand (via CoS or ML)
- **Reports to:** CoS with weekly performance digests

## Deployment Status

- Advanced significantly
- Active for NeuralEDGE internal marketing
- External deployment template ready for client engagements
