# Key Projects & Named Builds

## Context Vault
- **Role:** Central knowledge layer for all NEops
- **Scope:** Dual — Company + Private
- **Tech:** Convex + OpenAI embeddings (v1), evolving to Gemini/Qwen3 (v3)
- **Status:** Architected, active development
- **Full detail:** See `04_tech_and_memory/02_context_vault.md`

## CORTEX-PALACE v3
- **Role:** Unified memory system replacing ad-hoc per-NEop memory
- **Architecture:** Multi-tenant, cloud-native, graph-intelligent
- **Status:** Final spec, Phase 1 implementation pending
- **Full detail:** See `04_tech_and_memory/03_cortex_palace_v3.md`

## Axe Content Engine
- **Role:** Self-improving marketing content agent
- **Inspiration:** Chroma's Context-1
- **Stack:** AWS Strands SDK + Convex backend
- **Self-improvement:** NeP-based, tracks performance metrics
- **Status:** Advanced significantly, active

## CRM NeP
- **Role:** Agent-first CRM
- **Status:** Fully specced + partially built
- **Components:** Convex schema, CLI tool, dashboard
- **Outcome:** Retired — was over-engineered

## Neural (ML's Personal AI Executive Assistant)
- **Role:** ML's personal AI agent
- **Platform:** OpenClaw
- **Workspace Files:**
  - SOUL.md (identity)
  - MEMORY.md (semantic memory)
  - HEARTBEAT.md (periodic checks)
  - 12 SKILL.md files (installed skills)
- **Team Expansion Plan:** NEURAL-TEAM-DEPLOYMENT-PLAN.md for Rahul, Mansi, Shivam, Naveen, Ankit

## TeamPulse
- **Role:** Telegram-based 30-minute team pulse system
- **Purpose:** Async standup replacement
- **Platform:** Telegram bot
- **Deployment:** AWS EC2
- **Integration:** Feeds Team wing of CORTEX-PALACE → Tasks + Signals

## PULSE (Chief of Staff Command Center)
- **Role:** ML's command center dashboard
- **Features:**
  - Voice update transcription
  - Standup management
  - WebSocket real-time updates
- **Integration:** Ingests from TeamPulse + CoS NEop

## Recon SDR Agent (Yoga Studio Chain)
- **Role:** Lead generation for yoga studios in US/GB markets
- **Platform:** OpenClaw
- **Stack:** Apify (scraping) + Firecrawl (content extraction) + Convex (state)
- **Status:** Active in production

## OpenClaw Production Deployment
- **Platform:** AWS EC2 (Ubuntu 24.04, ap-south-1, 13.233.60.59)
- **Version:** v2026.3.3
- **Primary Model:** ZAI/GLM-5
- **Service:** systemd
- **Channels:** Matrix (primary), Telegram, WhatsApp
- **Documentation:** Full Matrix whitepaper written
- **Full detail:** See `02_neos_platform/04_openclaw_runtime.md`

## NE-HERMES (Retired)
- **Role:** Self-improving skill loop agent
- **Inspiration:** Nous Research's Hermes Agent
- **Status:** Built from scratch, then retired
- **Reason for retirement:** Patterns absorbed into NePs system (self-improvement became a first-class feature)

## NE-GSTACK
- **Role:** Wraps gstack (Garry Tan's slash-command AI factory)
- **Strategy:** Unforked wrapping for v0.1.0, customize later
- **Deep-dives completed on gstack philosophy:**
  - "Boil the Lake" principle
  - "Search Before Building" principle
  - Sprint process
  - 28+ skill patterns

## NEXUS (Company-level B2B Intelligence)
- **Full detail:** See `02_nexus_alte.md`
- **Role:** Company intelligence graph
- **DB:** Neo4j
- **Sources:** LinkedIn, Substack, news, websites, job postings
- **Status:** In development

## ALTE (Person-level B2B Intelligence)
- **Full detail:** See `02_nexus_alte.md`
- **Role:** Person profile builder
- **Architecture:** 6 pipeline stages, 8 data blocks
- **Context Modes:** 6 (sales, investor, meeting prep, etc.)
- **Status:** In development

## Customer Connect Emma (WhatsApp Shopping)
- **Full detail:** See `03_customer_connect_emma.md`
- **Role:** WhatsApp-native shopping assistant
- **Stack:** Strands + Redis + MongoDB + Supabase + Razorpay + AWS Personalize + Virtual Try-On
- **Status:** Heavily developed and tested

## TaskFlow CLI (NEops-native task engine)
- **Role:** Command-line task engine for NEops
- **Why:** Original TaskFlow was web-first SaaS; NEops need CLI/API, not UI
- **Integration:** NeP-compatible, NEop consumer model
- **Status:** Plan written, pending build

## Chief of Staff (CoS) NEop
- **Full System Design:** Completed
- **Backend:** Pi agent architecture
- **Deployment Package:** Completed
- **Role:** Meta-orchestrator above all other NEops
- **Hierarchy:** ML → CoS → (Aria, Recon, Forge, Axe, Emma + Scout floater)

## Aria HR Agent
- **Role:** HR-focused variant of Aria SDR
- **Functions:** Receives team standups, routes HR queries, coordinates interviews
- **Integration:** Daily standup ingestion, ad-hoc HR requests via CoS

## NeuralHQ Virtual Office PRD
- **Role:** Virtual office concept document
- **Status:** PRD written

## Legal Document Toolkit
- **Scope:** 200+ templates
- **Full detail:** See `07_legal_and_fundraising/01_legal_templates.md`

## ICD NEop (Zoo Media)
- **Full detail:** See `03_clients/04_zoo_icd_neop.md`
- **Role:** Image Content Director for Zoo Media's 8 agencies
- **Status:** Delivered, active

## AI Training Workshop Curricula
- **Role:** Multiple workshop curricula for AI Training service
- **Status:** Multiple produced

## ICP Documents for Manufacturing Verticals
- **Role:** Sub-industry ICP docs for manufacturing
- **Integration:** Feeds Aria's outreach targeting

## Document Toolkit (Comprehensive)
- **Scope:** 200+ templates across all document types
- **Includes:** NDA, MSA, SOW, DPA, invoices, proposals, case studies, audit reports, project charters, etc.
- **Skill:** `neuraledge-doc` — auto-generates personalized documents from templates

## Brand System
- **Skill:** `neuraledge-brand`
- **Role:** Enforces visual identity and messaging consistency
- **Usage:** All presentations, documents, emails, client-facing communications

## Payslip Generator
- **Role:** Employee payslip generation in .docx
- **Skill:** `payslip-generator`
- **Features:** Earnings, deductions, net pay calc, amount in words, bulk generation

## Premium Site Builder
- **Role:** End-to-end premium website builder workflow
- **Skill:** `premium-site-builder`
- **Features:** AI-generated visuals (Nano Banana, Kling, Higgsfield), scroll-driven animations, 3D effects, M.O.N.E.Y. framework

## MBA Visual Engine
- **Role:** Quirky editorial SVG illustrations for MBA/business concepts
- **Skill:** `mba-visual-engine`
- **Output:** Social media visuals, deck illustrations, blog post images

## Worldbuilding Writer
- **Skill:** `worldbuilding-writer`
- **Role:** Persuasive high-conversion content using applied psychology
- **Use:** Cold emails, outreach, pitch decks, proposals, LinkedIn, landing pages, case studies
