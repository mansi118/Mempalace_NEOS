# Outreach Playbook

## Core Philosophy

> Lead with the client's pain point, not NeuralEDGE's features.

## Message Architecture

### 1. Opening Hook
- Reference something specific to the prospect (social post, news, role change)
- Example: Akhilesh's "Invisible AI" LinkedIn post → entire pitch derived from his own language

### 2. Pain Acknowledgment
- Name the specific problem their company faces
- Don't generalize — use industry/role-specific detail

### 3. Bridge to NeuralEDGE
- Natural transition: "here's what we've done for similar companies"
- Proof points: Shinon Global stats (50–100x, 7%, 30min)

### 4. Low-Commitment CTA
- Free 2-week trial (single NEop)
- ₹1.5L AI Audit
- Free fractional AI Audit (5hr in-person for larger prospects)

## Sequence Design (Cold Email)

### Email 1: Specific Hook
- Subject: Reference their own words or specific event
- Body: 3–4 sentences max, specific value prop
- CTA: Soft ask (15-min call)

### Email 2 (3 days later): Case Study
- Subject: Peer / competitor transformation
- Body: Relevant case study (Shinon, Zoo)
- CTA: Invitation to AI Audit

### Email 3 (7 days later): Soft Close
- Subject: Genuine question
- Body: "Is this a priority this quarter?"
- CTA: Offer to step back if not relevant

### Email 4 (14 days later): Break-up
- Graceful exit
- Leave door open

## LinkedIn Approach

- Connection request with personalized note
- Warm up with content engagement (likes, thoughtful comments)
- DM only after 2–3 engagement touches
- Lead with a specific insight, not a pitch

## Message Templates

### To Agency CTOs (Zoo template)
> "At [Agency], we're seeing that the real ROI in 2026 comes from 'Invisible AI' — where tech handles the grunt work, allowing creative minds to focus on what moves the needle. We'd love to help you evolve [Agency] into India's most intelligent creative network. Happy to run a free fractional AI Audit — 5hr in-person session where we build a starting strategy you can implement in 2 days."

### To Build3 Partnership Context
- "We'll help Build3 productise its service offerings so they can scale beyond what your team can do manually"
- "Tangible value within the first week of engagement"
- "Full money-back guarantee for the entire first month — no questions"
- "Best way to experience the power of what we've built firsthand, before any investment"
- Pair with feedback request on the NEOS Bar Raiser tied to their investment thesis

## BANT Questions to Ask

- **Budget:** What's your current spend on [operations/content/lead gen]?
- **Authority:** Who else on your team should be in this conversation?
- **Need:** What's the single biggest bottleneck in your operations today?
- **Timeline:** When would you ideally want to see change?

## Trust Architecture Principles

1. **Transparency** — Share real numbers from Shinon, not abstract %
2. **Proof points** — 50–100x, 7%, 30min, Day 1 (concrete)
3. **Risk reversal** — Money-back guarantee, free trial, free audit
4. **Shared context** — Use their language, reference their ambitions
5. **Incremental commitment** — Don't ask for ₹25L first call; start with ₹1.5L audit

## Partnership Signaling

- "We build together" — positioning vs vendor-client
- Founder-to-founder tone (especially for other founders)
- Share what we're learning, not just selling

## Follow-up Cadence

| Lead Status | Touchpoint Frequency |
|-------------|---------------------|
| HOT | Daily/every 2 days |
| WARM | Weekly |
| COOL | Monthly educational content |
| COLD | Quarterly check-in |

## What to Never Do

- Auto-send client-facing emails without approval
- Mention competitors by name
- Discount below approved floor pricing without escalation
- Hand off leads without context (always log the reason)
- Use generic "hope this finds you well" openers

## Response to Specific Objections

### "We already have an AI team"
- "Great — we don't replace them. We give them NEOS as a platform to build on. Think of us as the L/L2 runway, they're the strategic layer."

### "Our industry is different"
- (Reference their sub-industry ICP doc — we have 35)
- "Actually we've worked with [similar ICP]. Here's what translated..."

### "Too expensive"
- Reframe to salary comparison (Zerodha principle)
- "₹5L/month = one mid-level hire. NEop handles the output of 3–5."

### "How is this different from ChatGPT/Claude?"
- "Chatbots need humans to use them. NEops do the work."
- Show ICD/Emma — fully autonomous

## Close Sequence

Once prospect is HOT:
1. Proposal sent with 3 pricing options
2. Customized deck (not generic)
3. Discovery call with ML or Consultant
4. NDA → SOW → MSA
5. Tier 1 deployment kicks off within 5 business days
