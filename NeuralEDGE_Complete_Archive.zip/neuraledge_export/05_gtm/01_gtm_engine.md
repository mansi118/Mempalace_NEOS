# GTM Engine — NeuralEDGE Go-to-Market

## North Star

- **Target:** 10 net-new clients/month
- **Revenue Goal:** ₹3 Crore MRR at ₹5L average retainer
- **3-Month Target:** 30 clients
- **Current Capacity:** 100 clients without hiring new consultants

## The Offer

**Primary:** NEOS Consulting Services
- Team of 2 from NeuralEDGE per engagement (1 NEOS Consultant + 1 Account Executive)
- Team builds personalized digital workforce (NEops)
- Builds NePs that improve each NEop's performance over time
- Transforms org into fully AI-native

## Pricing Structure (Recap)

- Monthly retainer model
- Target: ₹3–6L/month
- No minimum engagement length
- Retainer reassessed quarterly
- Bigger retainers = more consultants + reduced long-term NEC costs

## 7-Channel Outbound with Content Flywheel

### Active Channels (inferred from conversations)
1. **Cold Email / LinkedIn** (via Recon SDR)
2. **Content / LinkedIn Thought Leadership** (via Axe)
3. **Paid Ads** (₹8L budget from build3 raise)
4. **Warm Referrals** (existing clients)
5. **Events / Expo** (Flyer designed)
6. **Partnerships** (Tech Partners Deck)
7. **Inbound via Website** (neuraledge.in)

## Content Engine (Axe)

### Budget (from build3 raise)
- **Content & Brand:** ₹6L — fuels Axe content engine
- Distribution over creation (content creation runs on NEOS itself)

### Content Pillars (inferred)
- Strategy (AI transformation thinking)
- Implementation (how-to, technical)
- Industry Trends (AI-native operations)

### Planned Blog Topics (from website spec)
- "The 80% Promise: How to Identify What to Automate First"
- "Digital Employees vs. Chatbots: Understanding the Difference"
- "Why Knowledge Retention is the Hidden ROI of AI"
- "Building AI-Native Operations: A COO's Guide"

## Outreach Engine (Recon SDR)

- Built on OpenClaw
- Apify + Firecrawl stack
- Proxycurl/Apollo for lead data
- Deployed for yoga studio chain (US/GB markets)
- Generates qualified leads into pipeline

### Cold Email Best Practices (internal learnings)
- Lead with prospect's pain point, not NeuralEDGE features
- Ask BANT questions (budget, authority, need, timeline)
- Mirror prospect's communication style
- Never mention competitors by name
- Sequence design with follow-up cadence

## Aria (SDR NEop) Lead Scoring

**Total Score = ICP Fit (35%) + Engagement (25%) + Intent (25%) + Timing (15%)**

| Band | Score | Action |
|------|-------|--------|
| **HOT** | ≥80 | Immediate outreach, trigger proposal |
| **WARM** | 60–79 | Nurture sequence, weekly touchpoints |
| **COOL** | 40–59 | Monitor, send educational content |
| **COLD** | 20–39 | Low priority, quarterly check |
| **Disqualify** | <35 | Remove from pipeline |

## Target Geography

- **Primary:** India (mid-market services 50–200 employees)
- **Secondary:** Southeast Asia
- **Proven International:** Germany (Von Albert), US/GB (yoga chain)

## Paid Budget Allocation (from ₹25L build3 raise)

| Item | Amount | Purpose |
|------|--------|---------|
| Paid Ads | ₹8L | LinkedIn + Google, demo bookings + free POC signups |
| Content & Brand | ₹6L | Axe engine fuel — distribution, not creation |
| Outreach & Sales | ₹6L | Apollo/Proxycurl credits, email infra, Recon SDR |
| AWS Compute | ₹3L | EC2 scaling, Context Vault storage, model inference |
| Security & Tooling | ₹2L | API costs (OpenAI, Anthropic), monitoring, compliance |
| **Total** | **₹25L** | 80% GTM / 20% Infrastructure |

## Discovery Call Script (Structure)

Questions asked:
- Budget signal (₹3–10 lakh/month capacity)
- Authority (who makes the decision)
- Need (what's broken that AI can fix)
- Timeline (when do they want change)
- Qualification checklist
- Red flags to watch for

## Proposal Generation Flow

1. Discovery call completed (Aria/ML)
2. Proposal template selected based on ICP tier
3. Customization rules applied
4. Approval flow through ML
5. Proposal sent via NE-GTM automation (future)

## Demo Playbook

**Which NEops to show in what order for which ICP:**
- **Agency ICP:** ICD (Image Content Director) demo first
- **Professional Services ICP:** Aria (SDR) or COS (Chief of Staff)
- **D2C/Retail ICP:** Emma (WhatsApp Commerce)
- **Real Estate:** Recon (Lead Gen) + ALTE (Person Intel)

## Worldbuilding Writer Skill

Used extensively for:
- Personal brand scripts
- Pitch decks
- Outreach messages
- Client emails

Frameworks:
- Cognitive hospitality
- Atomic units
- Frame shift
- Reach from ground truth

## 8 Personal Brand Audience Personas (scripts written for each)
- Investors
- Clients
- Gen-Z peers
- Podcast format
- (and 4 more)

## Key Success Patterns (Lessons Learned)

### What works
- Warm intros + founder-to-founder tone
- Using prospect's own language (Akhilesh's "Invisible AI")
- Named protagonist stories (Priya at FoxyMoron)
- Specific metrics from Shinon Global (50–100x, 7%, 30min, Day 1)
- Offering free trial / free audit as low-commitment entry

### What doesn't work
- Generic pitch decks
- Feature-first messaging
- Long cold sequences without personalization
- Leading with platform, not business outcome
