# ICP Library — 35 Industry Documents

## Master Filter

**Industries where 50%+ of the workforce are knowledge workers.**

## Library Structure

35 ICP documents total, each covering either:
- A major industry horizontal
- Or a sub-industry vertical slice

Generated primarily for **Aria (SDR NEop)** to use for outreach targeting and personalization.

## Tier 1 (Primary Focus — India Service-Based)

### 1. Marketing / Creative / Media Agencies
- 80–90% knowledge workers
- Perfect fit
- Biggest traction (Zoo Media, prospective Crack'd, Asymmetrique)

### 2. Professional Services (Legal, CA, Consulting)
- 85–95% knowledge workers
- Perfect fit
- High per-hour billing — ROI easy to prove

### 3. Real Estate / Wellness / Hospitality
- Yoga studio chain already deployed
- Von Albert (Berlin luxury RE) is an active client

## Tier 2 (Secondary Focus)

### 4. EdTech
- Student-facing platforms
- Corporate L&D
- Assessment automation
- Content generation

### 5. Staffing
- Recruitment agencies
- HR tech

### 6. Architecture
- Design firms
- Construction consulting

## Other Industries in Library (partial list)

### 7. IT Services / SaaS / Dev Shops
- Large but competitive (many AI offerings)

### 8. Accounting Firms
- Validated fit

### 9. Healthcare (sliced into sub-industries)
- Patient-facing (chatbots, scheduling)
- Clinical documentation
- Diagnostics support
- Hospital operations
- Pharma / research

### 10. Manufacturing (sliced)
- Shop floor automation
- Quality inspection
- Supply chain / demand forecasting
- Document processing
- Internal knowledge systems

### 11. Financial Services / Fintech
### 12. E-commerce / D2C
### 13. Retail
### 14. Logistics
### 15. Insurance
### 16. Banking
### 17. Media / Publishing
### 18. BPO / KPO

## ICP Document Structure (each covers)

- Industry overview
- Sub-industry breakdown (where applicable)
- Typical pain points
- Knowledge worker density
- Budget capacity
- Decision-maker profile
- Typical tech stack / tools
- "Asleep" data goldmines (underutilized)
- NEop use cases (which NEops fit)
- Example automation opportunities
- Competitive landscape in this space
- Pitch angles that resonate
- Red flags / disqualifiers

## Sub-Industry Strategy

**Going by sub-industries, not horizontal:**
- One horizontal doc per industry
- 4–8 vertical sub-industry docs per major industry
- Targeted outreach by sub-industry (hits harder than generic)
- SEO/content: each sub-industry = landing page + blog series + LinkedIn pillar
- Sales: email sequences speak to sub-industry-specific pains

## Priority Rationale (why Tier 1 first)

1. **Knowledge worker density** — highest % of NEop-suitable work
2. **Warm traction** — ML already has conversations in these
3. **Ticket size fit** — ₹3–6L/month retainer matches their budget
4. **Prestige signal** — winning one agency unlocks many (Zoo = reference case)
5. **Marketplace density** — multiple agencies = multiple buyers for ICD NEop

## US / EU Target Band (International)

- Revenue band: $0.5M–$5M
- Engagement size: $10K–$200K
- Industries: Ops-heavy services, SaaS, ecom, BPO/KPO
- Entry ticket: $10K+, scales with scope

## India Corporate Target Band (Domestic + MNC Subsidiaries)

- All corporates including MNC India ops
- Scope: Education + advisory
- Focus: back-office automation, marketing automation, AI-first operating model

## Disqualifiers

- <50% knowledge workers
- <50 employees (can't absorb a ₹3–6L/month retainer sustainably)
- Already has strong internal AI team (will build in-house)
- No budget signal / exploration-only intent
- Willing to pay only per-project (retainer model won't land)
