# Raycast Platform - Comprehensive UI Summary
Generated: 2026-04-19T08:15:11.987Z

## Platform Overview
Raycast is a productivity launcher application for macOS (with Windows beta) described as "Your shortcut to everything." 
It is a collection of powerful productivity tools within an extendable launcher that is Fast, Ergonomic and Reliable.

## Core Value Proposition
- One-interface launcher replacing multiple apps/windows
- Keyboard-first workflow optimization
- Extensible via thousands of community-built extensions
- AI-powered features integrated directly into the OS-level experience
- "Take shortcuts, not detours. One interface, everything you need."

---

## WEBSITE UI STRUCTURE

### Navigation Bar (Fixed, Dark)
- Background: Near-black (#0A0A0A / very dark)
- Logo: Raycast flame icon (red/orange gradient) + "Raycast" text in white
- Nav Links: Store | Pro | AI | iOS | Windows | Teams | Developers | Blog | Pricing | Log in
- CTA Button: "Download" (white background, black text, Apple logo icon)
- Style: Glassmorphism/frosted effect, rounded rectangle container

---

## PAGE-BY-PAGE BREAKDOWN

### 1. HOMEPAGE (raycast.com)

#### Hero Section
- Background: Full-screen dark (#000) with dramatic red/crimson abstract diagonal shape gradient overlaying
- Abstract art: Diagonal strips/panels with red, burgundy, black colors — very dramatic and artistic
- Heading: "Your shortcut to everything." — Very large white bold text (display font ~6-8rem)
- Subheading: "A collection of powerful productivity tools all within an extendable launcher. Fast, ergonomic and reliable." — White/light gray, smaller font
- CTAs: 
  * "Download for Mac" button (dark background, white text, Apple logo)
  * "Download for Windows (beta)" button (dark background, white text, Windows logo)
- Version info: "v1.104.12 | macOS 13+ | Install via homebrew" — Small monospaced text
- Banner: "Introducing Glaze | Join waitlist →" — Pill-shaped dark banner

#### Feature Demo Section (Clipboard History)
- Dark background transitioning to near-black
- Subheading: "Take shortcuts, not detours." + "One interface, everything you need."
- Shows Raycast UI mock-up: Command palette with clipboard history
  * Dark modal window with list items
  * "Type to filter entries..." placeholder input
  * "All Types" dropdown
  * List items showing different clipboard content types
  * Preview pane on right showing image details
  * Bottom bar: "Clipboard History | Copy to Clipboard | Actions"
  * Context menu visible: "Copy to Clipboard, Share..., Open With..., Quick Look, Pin Entry"
- Sub-section: "Remember Everything. Stop playing Clipboard ping pong"

#### Values Section
- Heading: "It's not about saving time."
- Subheading: "It's about feeling like you're never wasting it."
- Keyboard visualization (faded/ghost keyboard)
- 4 value pillars:
  * Fast — "Think in milliseconds."
  * Ergonomic — "Keyboard First."
  * Native — "Pure performance."
  * Reliable — "99.8% crash-free rate."

#### Extensions Section
- Heading: "There's an extension for that."
- Subheading: "Use your favorite tools without even opening them."
- Tab filter: Productivity | Engineering | Design | Writing
- Extension cards grid (3 columns):
  * Linear — "Create, search and modify your issues without leaving your keyboard."
  * Google Translate — "Use Google Translate to effortlessly translate into multiple languages"
  * Spotify — "Search for music and podcasts, browse your library, and control playback."
  * Arc Browser, TinyPNG, 1Password, JIRA, Slack, Zoom, Timers, Pomodoro, Notion, Todoist, Google Search, Obsidian, Google Chrome, CleanShot X...
- Link: "Browse thousands more →"
- Carousel navigation arrows

#### AI Section
- Section label: "AI" (red text with red lines)
- Heading: "Your Mac just got smarter."
- Subheading: "AI where it's most useful - on your OS."
- Shows Raycast AI chat interface mock-up with sample prompt "How do I quit Vim?"
- 3 AI features:
  * "Ask Anything, Anytime, Anywhere." — Quick AI combines AI with the web
  * "Always On ChatGPT." — Stuck while coding? Need help writing an email?
  * "Your Automation Assistant." — Create your own AI Commands
- Link: "More about AI →"

#### Social Proof / Testimonials
- Heading: "Built for professionals like you."
- Subheading: "Used by seriously productive people."
- Horizontal scrolling carousel of user testimonials:
  * Guillermo Rauch (@rauchg), CEO, Vercel
  * Marques Brownlee (@MKBHD), Creator
  * Koen Bok (@koenbok), Founder, Framer
  * Adam Wathan (@adamwathan), Creator, Tailwind CSS
  * Wes Bos (@wesbos), Co-host, SyntaxFM
  * And many more tech professionals
- Each card shows: Avatar, name, Twitter handle, title, favorite feature, quote

#### Snippets / Automation Section
- Heading: "Don't repeat yourself."
- Subheading: "Automate the things you do all the time."
- Shows snippet demo: typing keyword → expands to full address
- Features:
  * Snippets — Create text shortcuts with keywords
  * Quicklinks — Quick links to websites/apps
  * Hotkeys and Aliases — Assign keyboard shortcuts

#### "What else can Raycast do?" Section
- Animated list of features cycling through:
  Take notes | Track flights | Convert anything | Search files | Run scripts | Manage windows | Plan your day | Remind you | Translate | Block distractions | Find text in screenshots | Insert Emojis
- Right side: Animated preview of Notes UI

#### Community Section
- Heading: "Stay in the loop."
- Two cards:
  * Slack — 37k members | "Join →"
  * X/Twitter — 90k followers | "Follow →"
- YouTube video thumbnails grid

#### Developer Section
- Heading: "Build the perfect tools."
- Subheading: "Our extension API is designed to allow anyone with web development skills to unleash the power of Raycast"
- Link: "Read the docs →"
- 4 developer features with FIG illustrations (technical line-art style):
  * React to macOS — "Build rich, native extensions with React, TypeScript and Node"
  * Built-in UI — "Our UI component library allows you to concentrate on the logic"
  * Batteries included — "A strongly typed API, hot-reloading and modern tooling"
  * Publish to the Store — "Submit your extension to the Raycast Store"

#### Final CTA Section
- Heading: "Take the short way."
- Subheading: "Download and use Raycast for free."
- Same download buttons as hero

#### Footer
5-column layout:
- Product: Store, Pro, Teams, Pricing, Changelog, Browser Extension, Developers, iOS, Windows, API Docs, Manual, Troubleshooting, Raycast vs Alfred, FAQ
- Core Features: Raycast AI, Notes, Focus, Clipboard History, Window Management, Snippets, File Search, Quicklinks, Calculator, Calendar, System, Emoji Picker
- Top Extensions: Design Tools, Developer Tools, Pomodoro Timer, Productivity, Project Management, Time Management, Transcript, Translation, Work From Home, AI
- Company: Manifesto, Customers, Careers, Terms of Service, Privacy Policy, Acceptable Use Policy, DPA, Trust Center, Press Kit, Contact
- Community: Community Stories, Ambassadors, Slack, X/Twitter, GitHub, Dribbble
- By Raycast: Try Raycast AI, Explore Snippets, Explore Quicklinks, Prompts, Chat Presets, ray.so, Icon Maker, Merch, Wallpapers
- Newsletter: Email signup with Subscribe button

---

### 2. PRICING PAGE (raycast.com/pricing)

#### Header
- Same navbar
- Background: Dark with red abstract diagonal art (same visual language as homepage)
- Toggle: "Monthly | Yearly (-20%)" — Toggle pill switch

#### Pricing Tiers (3 columns)
1. **Raycast (Free)**
   - Price: $0/month
   - Features: Core features (Clipboard History, Quicklinks, Calculator, Snippets, Emoji Picker, Window Management), Raycast AI (50 free messages), Raycast Notes (5 free), Raycast for iOS, Thousands of extensions, Custom Extensions, Developer Tooling
   - CTA: "Download" (dark button)

2. **Raycast Pro** (Highlighted/featured)
   - Price: $8/month ($96 billed annually, was $120)
   - Subtitle: "AI at your fingertips"
   - Blue verification badge icon
   - Features: Everything in Free + Raycast AI (multiple providers: Raycast, OpenAI, Anthropic, Perplexity, Mistral, Google, xAI + more), Cloud Sync, Translator, Unlimited Notes, Unlimited Clipboard History, Custom Window Management, Custom Themes
   - CTA: "Start Free Trial" (white button, outlined)

3. **Pro + Advanced AI**
   - Price: $16/month ($192 billed annually, was $240)
   - Subtitle: "The most intelligent models"
   - Red sparkles icon
   - Features: Everything in Pro + Advanced AI Models (OpenAI, Anthropic, Perplexity, Mistral, Google, xAI)
   - CTA: "Subscribe to Pro + Advanced AI" (dark button)

---

### 3. STORE PAGE (raycast.com/store)

#### Hero
- Dark background with colorful app icon grid (floating, blurred)
- Large heading: "Store"
- Subheading: "Sprinkle a little magic on your day. Connect your tools, and take your daily workflow to the next level."
- Search bar: Large dark input with "Search..." placeholder + "⌘K" keyboard shortcut indicator

#### Extension Listings
- Section: "Explore — Browse and install extensions built by the community"
- Featured section: "Our top picks to get you started"
  * Extension cards: Large icon, name, description, author, "Install Extension" button
  * Examples: Hacker News, Skills, TLDR Pages
- Tabs: All Extensions | Recently Added | Most Popular
- Platform filter: All | Apple | Windows
- Grid of extension cards: Icon, Name, Description, Author avatar+name, "Install Extension" button

---

### 4. AI PAGE (raycast.com/core-features/ai)

#### Hero
- Dark background with floating app icon collage (Spotify, Notion, GitHub, ChatGPT, etc. apps)
- Center: Raycast AI sparkle icon (red stars on dark background)
- Heading: "AI that works with your OS"

---

## DESIGN SYSTEM & VISUAL LANGUAGE

### Color Palette
- Background: #000000 (pure black) / #0A0A0A (near black)
- Surface cards: #111111 / #1A1A1A
- Text primary: #FFFFFF (white)
- Text secondary: #888888 / #666666 (gray)
- Accent: #FF4136 / #E53E3E (red/coral) — Raycast brand color
- Button primary (Download): White background, black text
- Button secondary: Dark #1A1A1A background, white text
- Borders: #222222 / #333333 (subtle dark borders)
- Highlighted card (Pro): Slightly lighter dark #1C1C1C

### Typography
- Display headings: Very large, bold, white, likely Inter or similar modern sans-serif
- Body text: Regular weight, white or gray
- Monospace: Used for version info, code snippets, some UI labels
- Font sizes: Hero headline ~80-96px, Section headers ~40-56px, Body ~16-18px

### Components
1. **Navigation Bar**: Glassmorphism dark pill, sticky, ~70px height
2. **Hero Section**: Full viewport height with dramatic gradient background art
3. **Section Container**: max-width ~1280px, centered, horizontal padding
4. **Feature Cards**: Dark rounded cards with subtle border, icon + title + description
5. **Extension Cards**: Large icon, title, subtitle, author row, install button
6. **Pricing Cards**: 3-column layout, middle card elevated/highlighted
7. **Toggle Switch**: Pill-style billing period toggle
8. **Search Bar**: Large dark input with keyboard shortcut badge
9. **Testimonial Carousel**: Horizontal scroll with profile photos
10. **Community Cards**: Dark cards with platform icon + stats + description + CTA
11. **Tab Navigation**: Pill-style active tab with dark/highlight contrast
12. **Keyboard Visualization**: Ghost/outline rendering of keyboard keys
13. **Footer**: Multi-column link grid, newsletter form

### Interactive Animations
- Mac desktop mockup animations (clipboard history filling in)
- AI chat typing animation
- Snippet keyword → expanded text animation
- Feature list cycling through items
- Carousel scroll for extensions and testimonials
- Scroll-triggered reveal animations throughout

### App Window Mockups
- Raycast launcher UI: Dark modal, ~600px wide, rounded corners
- Search input at top
- List of results with icons and labels
- Keyboard shortcut hints on right
- Bottom action bar with "Actions" button

---

## PLATFORM FEATURES SUMMARY

### Core Features
1. **Clipboard History** — Save and search clipboard items (text, images, links, colors, files)
2. **Window Management** — Left/Right/Top/Bottom halves, thirds, quarters, full screen
3. **File Search** — Fast Spotlight-like file finder
4. **Calculator** — Inline calculator with history
5. **Calendar** — View upcoming events from menu bar
6. **Snippets** — Text expansion shortcuts
7. **Quicklinks** — Custom browser/app launchers
8. **Emoji Picker** — Fast emoji search and insert
9. **System Commands** — Lock, restart, sleep, toggle settings
10. **Raycast AI** — AI chat integrated at OS level
11. **Raycast Notes** — Quick note capture
12. **Raycast Focus** — Distraction blocking

### Extension Categories
- Design Tools
- Developer Tools
- Pomodoro Timer
- Productivity
- Project Management
- Time Management
- Transcript
- Translation
- Work From Home
- AI

### Supported Platforms
- macOS 13+ (primary)
- Windows (beta)
- iOS (companion app)

### Teams Features
- Shared snippets, quicklinks, extensions
- Team management
